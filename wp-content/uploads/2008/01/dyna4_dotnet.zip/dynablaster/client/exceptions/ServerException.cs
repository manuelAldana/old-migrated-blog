using System;

namespace dynablaster.exceptions
{
	/// <summary>
	/// Server Exception werden geworfen, wenn es Probleme bei der Server 
	/// Kommunikation gegeben hat. 
	/// </summary>
	public class ServerException : System.ApplicationException
	{
		public ServerException(string message):base(message)
		{
			
		}

	}
}
