using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

using dynablaster.client.exceptions;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.exceptions;
using dynablaster.client.gui;

namespace dynablaster.client.delegates
{
	

	/// <summary>
	/// Der Delegate der vom Client f�r die Server-Verbindung verwendet wird
	/// </summary>
	public class ClientDelegate : IBusinessDelegate
	{
		/// <summary>
		/// adresse mit host:port
		/// </summary>
		private static string address="localhost:55555";
		/// <summary>
		/// remote objekt der menu-steuerung des servers 
		/// </summary>
		private IFacadeMenu menuServer;
		/// <summary>
		/// remote objekt der spiel-steuerung des servers
		/// </summary>
		private IFacadeGame gameServer;
		/// <summary>
		/// Event Wrapper f�r Callbacks damit remote delegates m�glich sind 
		/// </summary>
		private CallbackWrapper callbackWrapper;
		

		/// <summary>
		/// Erstellt eine Verbindung zum Server und holt sich die SessionFacade als 
		/// Objekt
		/// </summary>
		public ClientDelegate(TestEvent testEvent,JoinEvent joinEvent,StartEvent startEvent,GameEvent gameEvent)
		{	
			//default tcp channel mit '0', sprich client und registrierung
			TcpChannel chan= new TcpChannel(0);
			ChannelServices.RegisterChannel(chan);
			//remote-objekt holen von einem server
			MarshalByRefObject obj=(MarshalByRefObject) RemotingServices.Connect(
				typeof(IFacadeMenu),"tcp://"+address+"/dynablaster/SessionFacade");
			//testen, ob es ein remote-objekt gibt
			if(obj==null)
				throw new ServerException("Server object not found");
			//remote-objekt in instanzvariablen setzen
			menuServer= obj as IFacadeMenu;
			gameServer= obj as IFacadeGame;
			callbackWrapper=new CallbackWrapper(testEvent,joinEvent,startEvent,gameEvent);
		}



		//+++++++++++++++++++++METHODEN F�R MEN�STEUERUNG++++++++++++++++++++++++++++++++++++++
		//

		public string[] JoinGame()
		{
			return this.menuServer.JoinGame();
		}

		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void JoinGame(string game,string player)
		{
			this.menuServer.JoinGame(game, player,new StartEvent(this.callbackWrapper.LocallyHandleStartEvent),
								new GameEvent(this.callbackWrapper.LocallyHandleGameEvent));
		}

		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void NewGame(string game, string player)
		{
			try
			{
				this.menuServer.NewGame(game,player,new JoinEvent(this.callbackWrapper.LocallyHandleJoinEvent),
											new StartEvent(this.callbackWrapper.LocallyHandleStartEvent),
												new GameEvent(this.callbackWrapper.LocallyHandleGameEvent));
			}
			catch(RemotingException re)
			{
				//remoting exception an gui weiterleiten
				throw new ServerAccessException(re.Message);
			}
			
		}
		
		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game"></param>
		public void StartGame(string game)
		{
			try
			{
				this.menuServer.StartGame(game);
			}
			catch(RemotingException re)
			{
				//remoting exception an gui weiterleiten 
				throw new ServerAccessException(re.Message);
			}
		}

		//
		//++++++++++++++++++++++ENDE METHODEN F�R MEN�STEUERUNG+++++++++++++++++++


		//+++++++++++++++++++++METHODEN F�R GAMEPLAY+++++++++++++++++++++++++++++
		//

		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void PlayerMoveUp(string game, string player)
		{
			this.gameServer.PlayerMoveUp(game,player);
		}

		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void PlayerMoveRight(string game, string player)
		{
			this.gameServer.PlayerMoveRight(game,player);
		}

		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void PlayerMoveDown(string game, string player)
		{
			this.gameServer.PlayerMoveDown(game,player);
		}
		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="game">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void PlayerMoveLeft(string game, string player)
		{
			this.gameServer.PlayerMoveLeft(game,player);
		}

		/// <summary>
		/// siehe IBusinessDelegate
		/// </summary>
		/// <param name="name">siehe IBusinessDelegate</param>
		/// <param name="player">siehe IBusinessDelegate</param>
		public void PlaceBomb(string game, string player)
		{	
			this.gameServer.PlaceBomb(game,player);
		}


		public void ClientSendFinishedGame(string game)
		{
			this.gameServer.ClientSendsFinishedGame(game);
		}
		//
		//+++++++++++++++++++++ENDE METHODEN F�R GAMEPLAY++++++++++++++++++++++++

		

		public void TestDelegate()
		{
			this.menuServer.Hello(new TestEvent(this.callbackWrapper.LocallyHandleTestEvent));
			
		}
	}
}
