using System;

using dynablaster.shared_libs.callbacks;


namespace dynablaster.client.delegates
{

	/// <summary>
	/// BusinessDelegate Interface �ber den der Client mit Server
	/// kommuniziert.
	/// </summary>
	public interface IBusinessDelegate
	{
		//++++++++METHODEN F�R MEN�STEUERUNG++++++++++++++++++++++++
		//

		/// <summary>
		/// �bermittlung des Namens an den Server und Eintritt in
		/// Spielbeitritt-Auswahl
		/// </summary>
		/// <param name="game">spielname</param>
		/// <param name="player">Spielername</param>
		void JoinGame(string game, string player);
		/// <summary>
		/// meldet server, dass man sich einem spiel anschliessen will
		/// dieser gibt die ausw�hlbaren spiele zur�ck
		/// </summary>
		/// <returns>spiele, an denen teilgenommen werden kann</returns>
		string[] JoinGame();
		/// <summary>
		/// ein neues spiel mit spielf�hrernamen soll angemeldet werden,
		/// es wird aber noch nicht gestartet!!
		/// </summary>
		/// <param name="game">spielname</param>
		/// <param name="player">spielf�hrername</param>
		void NewGame(string game, string player);
		/// <summary>
		/// Startet Spiel, wird vom Spielf�hrer aufgerufen
		/// </summary>
		/// <param name="game"></param>
		void StartGame(string game);
		//
		//++++++++ENDE METHODEN F�R MEN�STEUERUNG+++++++++++++++++++


		//+++++++++METHODEN F�R GAMEPLAY++++++++++++++++++++++++
		//
		/// <summary>
		/// Spieler will sich nach oben bewegen
		/// </summary>
		/// <param name="game">spiel</param>
		/// <param name="player">spieler</param>
		void PlayerMoveUp(string game, string player);
		/// <summary>
		/// spieler will sich nach rechts bewegen
		/// </summary>
		/// <param name="game">spiel</param>
		/// <param name="player">spieler</param>
		void PlayerMoveRight(string game, string player);
		/// <summary>
		/// spieler will sich nach unten bewegen
		/// </summary>
		/// <param name="game">spiel</param>
		/// <param name="player">spieler</param>
		void PlayerMoveDown(string game, string player);
		/// <summary>
		/// spieler will sich nach links bewegen
		/// </summary>
		/// <param name="game">spiel</param>
		/// <param name="player">spieler</param>
		void PlayerMoveLeft(string game, string player);
		/// <summary>
		/// spieler legt auf aktueller position eine bombe
		/// </summary>
		/// <param name="game">spiel</param>
		/// <param name="player">spieler</param>
		void PlaceBomb(string game, string player);
		//	
		//++++++++ENDE METHODEN F�R GAMEPLAY++++++++++++++++++++++++++++

		/// <summary>
		/// client signalisiert server und spiel, dass er nicht mehr dabei ist,
		/// so dass ein l�schen des spieles seitens des spieleverwalters (SessionFacade)
		/// m�glich ist
		/// </summary>
		/// <param name="game">spielname</param>
		void ClientSendFinishedGame(string game);

		/// <summary>
		/// remote delegate test
		/// </summary>
		void TestDelegate();


	}
}
