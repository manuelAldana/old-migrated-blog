using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;

using dynablaster.client.gui.helper;
using dynablaster.client.delegates;
using dynablaster.client.exceptions;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;




namespace dynablaster.client.gui
{
	/// <summary>
	/// Zusammenfassung f�r Game.
	/// </summary>
	public class GameGUI : System.Windows.Forms.Form 
	{	
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button serverStart;
		private System.Windows.Forms.Button spielEinleiten;
		private System.Windows.Forms.Button spielTeilnahme;
		private System.Windows.Forms.Button spielBeitreten;
		private System.Windows.Forms.Button beitrittZur�ck;
		private System.Windows.Forms.Button einleiten;
		private System.Windows.Forms.Button einleitenZur�ck;
		private System.Windows.Forms.ComboBox weltauswahl;
		private System.Windows.Forms.ComboBox spielauswahl;
		private System.Windows.Forms.Button StartSpiel;
		private System.Windows.Forms.Button dateneingabe;
		private System.Windows.Forms.ComboBox farbauswahl;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel spielerliste;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label name1;
		private System.Windows.Forms.Label name2;
		private System.Windows.Forms.Label name3;
		private System.Windows.Forms.Label name4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button auswahlAktButton;
		
		//hilfsvariablen, damit clientseitig schon getestet werden
		//kann, ob spiel-bewegungen ausserhalb des spielfeldes passieren
		private const int MOVE_UP=0;
		private const int MOVE_RIGHT=1;
		private const int MOVE_DOWN=2;
		private const int MOVE_LEFT=3;

		/// <summary>
		/// F�rs perfomante loggen (�bers richtText field Log-befehle 
		/// dabei asynchron!!!
		/// </summary>
		private delegate void Logger(string s);
		private event Logger LoggerHandler;

		/// <summary>
		/// Unser Graphics f�rs Zeichnen
		/// </summary>
		private Graphics g;

		/// <summary>
		/// cache f�r die map, damit beim repaint nicht gleich serveranfrage 
		/// </summary>
		private GameObject[,] cachedMap;
		/// <summary>
		/// cache f�r die spieler, damit beim repaint nicht gleich serveranfrage
		/// </summary>
		private IList cachedPlayers;
		/// <summary>
		/// cache, der unexplodierten bomben
		/// </summary>
		private IList cachedBombs;
		/// <summary>
		/// anzahl felder x-richtung
		/// </summary>
		private int xBound;
		/// <summary>
		/// anzahl felder y-richtung
		/// </summary>
		private int yBound;
		/// <summary>
		/// flag, ob gameplay schon gestartet
		/// </summary>
		private bool gameStarted=false;
		/// <summary>
		/// flag, ob gesamtes spiel beendet ist 
		/// (erst dann ist ein programm exit mit enter m�glich)
		/// </summary>
		private bool gameFinished=false;


		/// <summary>
		/// Unsere Schnittstelle zum Server ->siehe BusinessDelegate-Pattern
		/// </summary>
		private IBusinessDelegate myBDelegate;
		
		/// <summary>
		/// delegat f�r das ausf�hren beim direkten spielstart
		/// </summary>
		private StartEvent myStartEvent;
		/// <summary>
		/// delegat f�r das update der teilnehmenden Spieler in der GUI 
		/// des Spielf�hrers
		/// </summary>
		private JoinEvent myJoinEvent;
		/// <summary>
		/// test event f�r testen des remote delegates
		/// </summary>
		private TestEvent myTestEvent;
		/// <summary>
		/// game event das w�hrend des gameplays auftritt
		/// </summary>
		private GameEvent myGameEvent;
		
		/// <summary>
		/// Name des Spielers
		/// </summary>
		private string playerName="";
		/// <summary>
		/// name des spiels
		/// </summary>
		private string gameName="";
		
		/// <summary>
		/// player, der diese GUI im gameplay steuert
		/// </summary>
		private Player player;


		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++KONSTRUKTOR, INIT DER GANZEN VARIABLEN UND CALLBACK+++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		/// <summary>
		/// GUI init f�r die men�steuerung 
		/// </summary>
		private GameGUI()
		{
			//damit bleibt das flackern beim update aus
			SetStyle(ControlStyles.DoubleBuffer|ControlStyles.AllPaintingInWmPaint
						|ControlStyles.UserPaint,true);
			InitializeComponent();
			//text f�r �berschrift setzen
			this.label1.Text="Willkommen bei Dynablaster for .Net";
			//logger-methode f�r logging-output
			LoggerHandler+=new Logger(LogToTextField);
			//gui dynablaster callback-methoden init
			this.myStartEvent=new StartEvent(StartGame);
			this.myJoinEvent=new JoinEvent(UpdateJoinPlayers);
			this.myTestEvent=new TestEvent(testDelegate);
			this.myGameEvent=new GameEvent(GameEventHandler);
			//tastatur events anmelden
			this.richTextBox1.KeyDown+=new KeyEventHandler(GameGUI_KeyDown);
			//paint event listener anmelden (implizit aufgerufen durch Invalidate()
			this.Paint+=new PaintEventHandler(this.repaint);
		}

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++ENDE KONSTRUKTOR, INIT DER GANZEN VARIABLEN UND CALLBACK+++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		
			


		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++METHODEN, DIE MODEL DES SPIELS ZEICHNEN++++++++++++++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				
		/// <summary>
		/// Zeichnet GameObject an bestimmten Grafikpunkten des Fensters
		/// </summary>
		/// <param name="obj">Spielobjekt welches gezeichnet werden soll</param>
		/// <param name="x">x-koordinate</param>
		/// <param name="y">y-koordinate</param>
		private void drawObject(GameObject obj,int x, int y)
		{
			if(obj is Stone)
				DrawObject.DrawGameObject(this.g,x,y,ColorManagmnt.brushStone);
			if(obj is Wall)
				DrawObject.DrawGameObject(this.g,x,y,ColorManagmnt.brushWall);
			if(obj is Way)
				DrawObject.DrawGameObject(this.g,x,y,ColorManagmnt.brushWay);
			if(obj is Treasure)
				DrawObject.DrawGameObject(this.g,x,y,ColorManagmnt.brushTreasure);
		}
		/// <summary>
		/// Zeichnet die game Items (Spieler oder Bombe)
		/// </summary>
		/// <param name="item">Spielitem welches gezeichnet werden soll</param>
		/// <param name="x">x-koordinate</param>
		/// <param name="y">y-koordinate</param>
		private void drawItem(Object item, int x, int y)
		{
			//if: item ist ein spieler
			if(item is Player){
				if(((Player)item).GetNumber()==1){
					DrawObject.DrawGamePlayer(this.g,x,y,ColorManagmnt.brushPlayer1);
					return;
				}
				if(((Player)item).GetNumber()==2){
					DrawObject.DrawGamePlayer(this.g,x,y,ColorManagmnt.brushPlayer2);
					return;
				}
				if(((Player)item).GetNumber()==3){
					DrawObject.DrawGamePlayer(this.g,x,y,ColorManagmnt.brushPlayer3);
					return;
				}
				if(((Player)item).GetNumber()==4){
					DrawObject.DrawGamePlayer(this.g,x,y,ColorManagmnt.brushPlayer4);
					return;
				}
			}
			//if: item ist eine bombe
			if(item is Bomb)
				DrawObject.DrawGameBomb(this.g,x,y,ColorManagmnt.brushBomb);
		}

		/// <summary>
		/// zeichnet eine explosion (epizentrum + benachbarte felder) 
		/// </summary>
		/// <param name="x">x-koord des epizentrums</param>
		/// <param name="y">y-koord des epizentrums</param>
		/// <param name="reichweite"></param>
		private void drawExplosion(int x, int y, int reichweite)
		{
			//hilfsvariablen f�r nachbarfelder
			int leftX, rightX, upperY, lowerY;
			//erst epizentrum zeichnen
			DrawObject.DrawGameObject(g,x,y,ColorManagmnt.brushEpicenter);
			//in reichweite bezogene felder ebenfalls anzeigen
			for(int i=1;i<=reichweite;i++)
			{	
				leftX=x-i;
				rightX=x+i;
				upperY=y-i;
				lowerY=y+i;
				//if:oberes feld nicht ausserhalb spielfeld
				if(upperY>=0)
					DrawObject.DrawExplosion(this.g,x,upperY,ColorManagmnt.brushExplosion);
				//if:rechtes feld nicht ausserhalb spielfeld
				if(rightX<=this.xBound)
					DrawObject.DrawExplosion(this.g,rightX,y,ColorManagmnt.brushExplosion);
				//if:unteres feld nicht ausserhalb spielfeld
				if(lowerY<=this.yBound)
					DrawObject.DrawExplosion(this.g,x,lowerY,ColorManagmnt.brushExplosion);
				//if:linkes feld nicht ausserhalb spielfeld
				if(leftX>=0)
					DrawObject.DrawExplosion(this.g,leftX,y,ColorManagmnt.brushExplosion);
			}
		}


		/// <summary>
		/// zeichnet das gesamte model (gameobjekte, spieler, bomben) des spiels
		/// </summary>
		private void printWorld()
		{
			//if:keine grafikobjekte vorhanden
			if(cachedMap==null)
				//return ohne zu zeichnen
				return;
			//spielwelt anzeigen mit map und players 
			this.PrintMap(this.cachedMap);
			this.PrintPlayers(this.cachedPlayers);
			this.PrintBombs(this.cachedBombs);
		}

		/// <summary>
		/// zeichnet alle nicht explodierten bomben des spielfeldes
		/// </summary>
		/// <param name="bombs">liste von bomben</param>
		private void PrintBombs(IList bombs)
		{
			//keine bomben vorhanden
			if(bombs==null) 
				//return, da nichts zu zeichnen
				return;
			//alle bomben in der liste 
			foreach(Bomb b in bombs)
			{
				//sollen gezeichnet werden
				this.drawItem(b,b.GetXCoord(),b.GetYCoord());
			}
		}

		/// <summary>
		/// zeichnet die gesamte welt der GameObjects ohne Items
		/// </summary>
		private void PrintMap(GameObject[,] map)
		{
			//l�ngen der arrays ermitteln
			int x=map.GetLength(0);
			int y=map.GetLength(1);
			for(int i=0;i<x;i++)
				for(int j=0;j<y;j++)
					//objekt zeichnen
					this.drawObject(map[i,j],i,j);
		}

		/// <summary>
		/// zeichnet spieler auf dem spielfeld
		/// </summary>
		/// <param name="players"></param>
		private void PrintPlayers(IList players)
		{
			//if:keine spieler vorhanden
			if(players==null)
				//return, da nichts zu zeichnen da
				return;
			//alle spieler der liste
			foreach(Player p in players)
			{
				//sollen gezeichnet werden
				drawItem(p,p.getXCoord(),p.getYCoord());
			}
		}
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++++++++++ENDE METHODEN DIE DAS MODEL ZEICHNEN++++++++++++++++++++
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++






		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++++++++++++DEBUG AUSGABEN AN DAS RICH TEXT FIELD++++++++++++++++++
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		/// <summary>
		/// F�gt eine Zeile in das RichText-Field ein
		/// </summary>
		/// <param name="s">Text, der geschrieben werden soll</param>
		private void LogToTextField(string s)
		{
			this.richTextBox1.AppendText(s+"\r\n");
		}
		/// <summary>
		/// F�r das Loggen in das Textfeld mit Zeilenumbruch, wegen Performance
		/// wird hier asynchroner Aufruf verwendet 
		/// </summary>
		/// <param name="s">Text, der geschrieben werden soll</param>
		public void Log(string s)
		{
			Object[] obj={s};
			//asynchroner Aufruf mit Hilfe von LoggerDelegaten
			BeginInvoke(LoggerHandler,obj);
		}
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//++++++++++++++++++ENDE DEBUG AUSGABEN AN DAS RICH TEXT FIELD+++++++++++++++	
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++





		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++METHODEN, DIE EINZELNE FENSTER AUFBAUEN ODER DARSTELLEN++++++++++
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		/// <summary>
		/// Erstellt Fenster f�r die Einleiten/Beitritt Auswahl
		/// </summary>
		protected void menuNewJoinWindow()
		{
			//remove "Mit Server Verbinden" button
			Controls.Remove(serverStart);
			//namen-ermittlung
			//variable, um loop zu steuern
			bool loop=true;
			//loop, damit keine leeren namen m�glich
			while(loop)
			{
				//dialog f�r Namen�bermittlung
				VerbindenDialog dialog=new VerbindenDialog();
				if(dialog.ShowDialog()==DialogResult.OK)
					//if: name nicht aus einem leeren string
					if(!((this.playerName=dialog.GetName()).Equals("")))
						//schleife beenden
						loop=false;
			}
			Log("Spielername wurde vermerkt: "+this.playerName);
			//label �ndern und anzeigen
			this.label1.Text="Hallo "+this.playerName+", bitte w�hle aus:"; 
			Controls.Add(this.label1);
			//neue buttons anzeigen
			Controls.Add(this.spielEinleiten);
			Controls.Add(this.spielBeitreten);
		}

		/// <summary>
		/// fenster, wo spieler, die an einem konkreten spiel teilnehmen wollen
		/// warten bis spielf�hrer das spiel startet
		/// </summary>
		protected void waitForStartWindow(string game){
			this.label1.Text="Bitte warten bis Spielf�hrer Spiel "+game+" startet";
			Controls.Remove(this.auswahlAktButton);
			Controls.Remove(this.label3);
			Controls.Remove(this.spielauswahl);
			Controls.Remove(this.spielTeilnahme);
		}

		/// <summary>
		/// fenster, wo spieler sich ein bestimmtes spiel zum teilnehmen
		/// aussuchen 
		/// </summary>
		protected void chooseGameWindow(){
			try{
				//buttons, die nicht mehr ben�tigt weg vom fenster
				Controls.Remove(this.spielEinleiten);
				Controls.Remove(this.spielBeitreten);
				this.label1.Text="Bitte gew�nschtes Spiel ausw�hlen!";
				this.label3.Text="Spiele :";
				Controls.Add(this.label3);
				Controls.Add(this.spielauswahl);
				Controls.Add(this.auswahlAktButton);
				string[] auswahl=myBDelegate.JoinGame();
				//combo box mit schon angemeldeten spielen f�llen
				this.spielauswahl.BeginUpdate();
				//combo box resetten, damit namen nicht doppelt auftauchen
				this.spielauswahl.Items.Clear();
				for(int i=0;i<auswahl.Length;i++)
					this.spielauswahl.Items.Add(auswahl[i]);
				//fertig mit f�llen
				this.spielauswahl.EndUpdate();
				//bis kein spiel ausgew�hlt wurde button inaktiv machen
				this.spielTeilnahme.Enabled=false;
				Controls.Add(this.spielTeilnahme);
			}
			catch(DynablasterException de)
			{
				Log(de.Message);
			}
		}

		/// <summary>
		/// Fenster, wo der Spielerf�hrer auf gen�gend viele
		/// Spieler wartet und dann startet
		/// </summary>
		protected void startWindow(){
			//erstmal alle nicht mehr ben�tigten buttons weg
			Controls.Remove(this.spielEinleiten);
			Controls.Remove(this.spielBeitreten);
			//spielnamen-ermittlung
			bool loop=true;
			//loop, damit kein leerer name m�glich ist
			while(loop){
				//dialog f�r spielnamenermittlung
				EinleitenDialog dialog=new EinleitenDialog();
				if(dialog.ShowDialog()==DialogResult.OK)
					if(!((this.gameName=dialog.GetName()).Equals("")))
						loop=false;
			}
			//fall, dass spielname schon existiert abfangen
			try{
				//spiel beim server mit namen anmelden
				myBDelegate.NewGame(this.gameName,this.playerName);
			}
				//spielname existiert schon
			catch(DynablasterException de){
				Log(de.Message);
				startWindow();
			}
			this.label1.Text="Folgendes Spiel steht vor dem Start: "+gameName;
			//liste der spieler
			Controls.Add(this.label2);
			Controls.Add(this.spielerliste);
			//button f�r spielstart
			Controls.Add(this.StartSpiel);
		}

		/// <summary>
		/// methode, die phase nach dem spiel einleitet, entweder man hat gewonnen
		/// oder verloren
		/// </summary>
		/// <param name="winner">flag, ob man gewinner oder nicht ist</param>
		/// <param name="mesg">anzeige f�r gewinner, ob wegen schatz oder 
		/// alle anderen tot</param>
		private void CleanUpGame(bool winner, string mesg)
		{
			Log("!!!Spiel ist zu Ende!!!");
			if(winner)
				Log(mesg);
			else
				Log("GameOver. "+mesg);
			//eventhandler abmelden, kein key eingaben mehr 
			this.richTextBox1.KeyDown-=new KeyEventHandler(this.GameGUI_KeyDown);
			//if:gesamtes spielende (alle tot, oder schatz gefunden)
			if(this.gameFinished)
			{
				//fenster aufrufen mit meldung, das spielende
				//signal an server, dass er am spiel nicht mehr teilnimmt
				this.myBDelegate.ClientSendFinishedGame(this.gameName);
				//variablen resetten
				this.playerName=null;
				this.gameName=null;
				this.cachedPlayers=null;
				this.cachedBombs=null;
				this.cachedMap=null;
				Log("Bitte 'Enter' dr�cken, um Programm zu verlassen.");
				//neuer handler, der enter event als exit verarbeitet
				this.richTextBox1.KeyDown+=new KeyEventHandler(this.FinishedGame_KeyDown);
			}
		}


				
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++ENDE METHODEN, DIE EINZELNE FENSTER AUFBAUEN ODER DARSTELLEN+++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	



		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//++++++++++++++++++++HELPER METHODEN F�R GUI +++++++++++++++++++++++++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		/// <summary>
		/// fragt ab, ob die bewegung (schritt nach oben, rechts etc.) nicht
		/// zu einer position ausserhalb des erlaubten spielfeldes f�hrt
		/// </summary>
		/// <param name="dir">richtung als int-konstanten</param>
		/// <returns></returns>
		private bool isItemOutOfBounds(int dir)
		{
			if(dir==GameGUI.MOVE_UP)
				if(this.player.getYCoord()-1<0){
					Log("Spieler kann nicht weiter nach oben!");
					return true;
				}
			if(dir==GameGUI.MOVE_RIGHT)
				if(this.player.getXCoord()+1>this.xBound){
					Log("Spieler kann nicht weiter nach rechts!");
					return true;
				}
			if(dir==GameGUI.MOVE_DOWN)
				if(this.player.getYCoord()+1>this.yBound){
					Log("Spieler kann nicht weiter nach unten");
					return true;
				}
			if(dir==GameGUI.MOVE_LEFT)
				if(this.player.getXCoord()-1<0){
				  Log("Spieler kann nicht weiter nach links");
				  return true;
				  }
			return false;
		}

		/// <summary>
		/// setzt den spieler, der die GUI hier steuert, wird anhand
		/// des namens identifierzt
		/// </summary>
		/// <param name="cachedPlayers">menge der spieler die durchsucht wird</param>
		private void SetPlayer(IList cachedPlayers)
		{
			foreach(Player p in cachedPlayers)
			{
				if(p.GetName().Equals(this.playerName)){
					this.player=p;
					Log("Player dieser GUI wurde gesetzt: "+this.player.GetName());
					//fertig gesucht also return
					return;
				}
			}
		}

		/// <summary>
		/// �berpr�ft aus einer gegebenen menge von toten spielern,
		/// ob der eigene spieler nicht schon tot ist
		/// </summary>
		/// <param name="players"></param>
		/// <returns></returns>
		private bool IsPlayerDead(IList players)
		{
			//if:liste nicht initialisiert -> keine spieler gestorben
			if(players==null)
				return false;
			//menge, der gestorbenen spieler durchsuchen
			foreach(Player p in players)
			{
				//if: der eigene spieler ist in der gestorbenen-spielermenge
				//identifikation anhand des namens
				if(p.GetName().Equals(this.playerName))
					return true;
			}
			//keine �bereinstimmung gefunden -> eigener spieler lebt noch
			return false;
		}
	

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//++++++++++++++++++++ENDE HELPER METHODEN F�R GUI +++++++++++++++++++++++++++++++
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++





	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//++++++++++++++++++++++EVENT_HANDLER+++++++++++++++++++++++++++++++++++++++
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++		
		
		/// <summary>
		/// zentrale stelle, wo die gameEvent callbacks seitens des servers
		/// eingehen, diese methode identifiziert dabei den "genaueren" event
		/// und leitet diesen an die entsprechende methode weiter
		/// </summary>
		/// <param name="args">argumente des game-events</param>
		private void GameEventHandler(DynaEventArgs args)
		{
			lock(this)
			{
				//if: es handelt sich um ein player-moved event
				if(args is PlayerMovedArgs)
				{
					Log("Ein PlayerMovedEvent ist angekommen");
					this.PlayerMovedHandler((PlayerMovedArgs) args);
					//event fertigabgearbeitet ->return;
					return;
				}
				//if: es ist ein event, wo bombe gelegt oder explodiert
				if(args is BombEventArgs)
				{
					Log("Ein BombEvent ist angekommen");
					this.BombEventHandler((BombEventArgs) args);
					//event fertig abgearbeitet ->return
					return;
				}
				//if: es handelt sich um ein map changed event (karte mit gameObjects hat sich ge�ndert
				if(args is MapChangedEventArgs)
				{
					Log("Ein MapChangedEvent ist angekommen");
					this.MapChangedEventHandler((MapChangedEventArgs) args);
					//event fertig abgearbeitet ->return
					return;
				}
				//if: es handelt sich um ein event, wo ein spieler gewonnen hat
				if(args is WinnerEventArgs)
				{
					Log("Ein WinnerEvent ist angekommen");
					this.WinnerEventHandler((WinnerEventArgs)args);
					//event fertig abgearbeitet ->return
					return;
				}
				//if: es handelt sich um ein event, wo ein spieler gestorben ist
				if(args is PlayerKilledEventArgs)
				{
					Log("Ein PlayerKilledEvent ist angekommen");
					this.PlayerKilledEventHandler((PlayerKilledEventArgs)args);
					//event fertig abgearbeitet ->return
					return;
				}
			}
			//Achtung: undefinierter Zustand!!!!
			Log("Fehler: Event wurde nicht erkannt!!");
		}

		/// <summary>
		/// handler, der spielerbewegungen, die beim server zuvor registriert 
		/// wurden anzeigt
		/// </summary>
		/// <param name="args">argumente des plaver-moved-events</param>
		private void PlayerMovedHandler(PlayerMovedArgs args)
		{
			Log("Es wurde ein PlayerMovedEvent erhalten!");
			//spielerliste anpassen
			Player player=((PlayerMovedArgs)args).GetPlayer();
			foreach(Player p in this.cachedPlayers)
				//if:name in der spielerliste wurde gefunden
				if(p.GetName().Equals(player.GetName()))
				{
					//spielerpositionen aktualisieren 
					p.setXCoord(player.getXCoord());
					p.setYCoord(player.getYCoord());
				}
			//gesamtes spielfeld (gameobjects, bomben, player) neu zeichnen
			printWorld();
		}

		/// <summary>
		/// f�hrt den bomb-event auf gui-seite aus, dabei gibt es zwei m�glichkeiten
		/// 1)es wurde eine bombe gelegt
		/// 2)es ist eine bombe explodiert (spielersterben wird mit�berpr�ft)
		/// </summary>
		/// <param name="args">argumente des bomben-events</param>
		private void BombEventHandler(BombEventArgs args){
			Log("Es wurde ein BombEvent erhalten!");
			//abfragen, ob es sich um bombenlegen oder explosionsevent
			//handelt
			//if: es handelt sich um ein explosions event 
			if(args.GetExplosionEventFlag()){
				Log("Bombe ist explodiert");
				//explodierte bombe als info holen
				Bomb explodedBomb=args.GetBombExploded();
				//gesamte explosion auf spielfeld darstellen
				this.drawExplosion(explodedBomb.GetXCoord(),
					explodedBomb.GetYCoord(),Bomb.power);
				//KLEINER WARTEZEITPUNKT, DAMIT DIE EXPLOSION ZU SEHEN IST
				Thread.Sleep(550);
			}
			//fall hier tritt sowohl bei keiner als auch bei einer explosion ein
			//bomben-menge aktualisieren, da durch explosion bombe weniger
			this.cachedBombs=args.GetBombsPlaced();
			//gesamtes spielfeld (gameobjects, bomben, player) neu zeichnen
			printWorld();
		}

		/// <summary>
		/// handler, der vom server gezeigte spielkarten�nderungen (stein ist 
		/// Weg etc.) auf GUI seite ausf�hrt bzw. anzeigt
		/// </summary>
		/// <param name="args">argumente des map-changed-events</param>
		private void MapChangedEventHandler(MapChangedEventArgs args){
			Log("Es wurde ein MapChangedEvent erhalten!");
			//dementsprechend die karte in der gui aktualisieren
			this.cachedMap=((MapChangedEventArgs)args).GetChangedMap();
			//gesamtes spielfeld (gameobjects, bomben, player) zeichnen
			printWorld();
		}

		/// <summary>
		/// behandelt das winner-event, �berpr�ft, ob man selber der gweinner ist
		/// und wenn nicht gibt andere meldung entsprechend aus
		/// </summary>
		/// <param name="args"></param>
		private void WinnerEventHandler(WinnerEventArgs args){
			Log("Es wurde ein WinnerEvent erhalten!");
			//es gibt einen gewinner->spiel ist also beendet
			//->flag setzen
			this.gameFinished=true;
			//seinen eigenen namen mit dem gewinner vergleichen
			//if: man ist der gewinner hat den schatz gefunden
			if(args.GetWinner().GetName().Equals(this.playerName))
				this.CleanUpGame(true,"Gl�ckwunsch Schatz gefunden!");
			//else: man ist nicht der gewinner
			else
				this.CleanUpGame(false,"Sorry, "+args.GetWinner().GetName()+
										" war beim Brandschatzen schneller");
		}

		private void PlayerKilledEventHandler(PlayerKilledEventArgs args){
			//alle spieler der gui-sicht durchsuchen, um den toten player herauszufinden
			foreach(Player p in this.cachedPlayers){
				//if: namen�bereinstimmung in der gui-spieler-liste mit dem toten
				//spieler gefunden
				if(p.GetName().Equals(args.GetKilledPlayer().GetName())){
					lock(this.cachedPlayers)
						//aus der menge der in GUI befindlichen spieler entfernen
						this.cachedPlayers.Remove(p);
					//�berpr�fen, ob nicht alle tot, keine spieler auf dem feld mehr
					//->alle haben verloren
					//spielermenge leer
					if(this.cachedPlayers.Count==0){
						Log("Alle spieler sind tot!");
						this.gameFinished=true;
						this.printWorld();
						this.CleanUpGame(false,"Kein Gewinner!");
						return;
					}
					//welt ohne tote spieler anzeigen
					this.printWorld();
					//�berpr�fen, ob man nicht selber der tote spieler ist
					//if:der tote spieler man selber ist (identifikation �ber namen)
					if(p.GetName().Equals(this.playerName))
						//spielende als verlierer
						this.CleanUpGame(false,"Sorry, ne Bombe hat dich erwischt!");
				}
			}
		}



		/// <summary>
		/// methode, die ausgef�hrt wird, wenn das spiel konkret gestartet wird
		/// </summary>
		/// <param name="args">event-args</param>
		public void StartGame(GameInitArgs args){
			Log("spiel wird gestartet");
			//andere Controls removen
			Controls.Remove(this.StartSpiel);
			Controls.Remove(this.label1);
			Controls.Remove(this.spielerliste);
			Controls.Remove(this.label2);
			//zeichenobjekt init, wird jetzt gebraucht
			this.g=this.CreateGraphics();
			//den cache f�llen
			this.cachedMap=args.GetGameObjects();
			this.cachedPlayers=args.GetPlayers();
			//den spieler dieser gui setzen
			this.SetPlayer(this.cachedPlayers);
			//grenzen festlegen, damit bewegungs-abfragen erleichtert werden
			//-1 abziehen, weil bei den feldern ab 0 angefangen wird zu z�hlen
			this.xBound=cachedMap.GetLength(0)-1;
			this.yBound=cachedMap.GetLength(1)-1;
			//flag setzen, dass gameplay gestartet hat
			this.gameStarted=true;
			//zeichnen
			this.printWorld();
		}

		/// <summary>
		/// listener f�r den fall, dass neue spieler sich einem spiel anschliessen wollen
		/// f�r spielf�hrer gedacht, damit er diese angezeigt bekommt
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="args"></param>
		public void UpdateJoinPlayers(JoinEventArgs args){
			Log("�nderung in Spielermenge");
			//array aus args auslesen
			string[] players=args.GetNames();
			//entsprechend der spielermenge namen in GUI anzeigen
			if(players.Length>0)
				this.name1.Text="Spieler 1: "+players[0];
			if(players.Length>1)
				this.name2.Text="Spieler 2: "+players[1];
			if(players.Length>2)
				this.name3.Text="Spieler 3: "+players[2];
			if(players.Length>3)
				this.name4.Text="Spieler 4: "+players[3];
		}


		/// <summary>
		/// Nach Klicken soll eine Verbindung zum Server hergestellt und
		/// der Name �bermittelt werden
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">eventArgs</param>
		private void serverStart_Click(object sender, System.EventArgs e){
			try{
				//zum remote-server verbinden
				Log("ClientDelegate init");
				//business delegate erstellen und gleichzeitig delegates f�r callbacks
				//�bergeben
				this.myBDelegate=new ClientDelegate(this.myTestEvent,this.myJoinEvent,
													this.myStartEvent,this.myGameEvent);
				Log("Server-Verbindung hergestellt...");
				//->zum n�chsten Men�punkt
				menuNewJoinWindow();
			}
			//fehler bei der verbindung zum server
			catch(ServerAccessException sae){
				Log(sae.Message);
			}
		}


		/// <summary>
		/// methode wird aufgerufen, wenn die tastatur gedr�ckt wird,
		/// �berpr�ft die gedr�ckte taste und verarbeitet diese entsprechend
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void GameGUI_KeyDown(object sender, KeyEventArgs e){
			//if:gameplay ist noch nicht gestartet worden
			if(!gameStarted)
				//keine tastatur befehle verarbeiten
				return;
			//try f�r application exception, die vom server geworfen werden k�nnten
			//z.B. spielerbewegung nicht m�glich weil wand ein hindernis ist
			//ABARBEITUNG VON SPIELERBEWEGUNGS-BEFEHLEN
			try{
				//KEY NACH OBEN GEDR�CKT
				if(e.KeyCode==Keys.Up)
					//if: spieler ausserhalb spielfeldes
					if(this.isItemOutOfBounds(GameGUI.MOVE_UP))
						return;
					else{
						//erlaubte bewegung also weiterreichen an server
						this.myBDelegate.PlayerMoveUp(this.gameName,this.playerName);
						//abarbeitung des tastendrucks zu ende -> return
						return;
					}
				//KEY NACH RECHTS GEDR�CKT
				if(e.KeyCode==Keys.Right){
					//if:spieler ausserhalb spielfeldes
					if(this.isItemOutOfBounds(GameGUI.MOVE_RIGHT))
						return;
					else{
						//erlaubte bewegung also weiterreichen an server
						this.myBDelegate.PlayerMoveRight(this.gameName,this.playerName);
						//abarbeitung des tastendrucks zu ende -> return
						return;
					}
				}
				//KEY NACH UNTEN GEDR�CKT
				if(e.KeyCode==Keys.Down)
					//if:spieler ausserhalb spielfeldes
					if(this.isItemOutOfBounds(GameGUI.MOVE_DOWN))
						return;
					else{
						//erlaubte bewegung also weiterreichen an server
						this.myBDelegate.PlayerMoveDown(this.gameName,this.playerName);
						//abarbeitung des tastendrucks zu ende -> return
						return;
					}
				//KEY NACH LINKS GEDR�CKT
				if(e.KeyCode==Keys.Left)
					//if:spieler ausserhalb spielfeldes
					if(this.isItemOutOfBounds(GameGUI.MOVE_LEFT))
						return;
					else{
						//erlaubte bewegung also weiterreichen an server
						this.myBDelegate.PlayerMoveLeft(this.gameName,this.playerName);
						//abarbeitung des tastendrucks zu ende -> return
						return;
					}
			}
				//exception, die geworfen wurde, weil ein hindernis die bewegung blockiert
			catch(DynablasterException de){
				//fehlermeldung des servers anzeigen
				Log(de.Message);
			}
			//ABARBEITUNG VON BOMBEN-BEFEHLEN
			try{
				if(e.KeyCode==Keys.Enter){
					Log("Bombe wird gelegt");
					this.myBDelegate.PlaceBomb(this.gameName,this.playerName);
				}
			}//fehlerfall bombe legen, wo schon eine liegt
			catch(DynablasterException de){
				Log(de.Message);
			}
		}

		/// <summary>
		/// key handler, wenn gameplay vorhanden ist ->  beendet 
		/// client-applikation vollst�ndig
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="args"></param>
		private void FinishedGame_KeyDown(object sender, KeyEventArgs args){
			//if:enter gedr�ckt
			if(args.KeyCode==Keys.Enter)
				//fenster schliessen, applikationsende!!!
				this.Close();
		}

		/// <summary>
		/// handler, wenn spieler auf den button f�r einen wunsch der
		/// spielteilnahme klickt 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void spielBeitreten_Click(object sender, System.EventArgs e)
		{
			//neues auswahlfenster
			this.chooseGameWindow();		
		}

		/// <summary>
		/// klick-event, wenn man auf Einleiten button klickt.
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">event</param>
		private void spielEinleiten_Click(object sender, System.EventArgs e)
		{
			//startfenster zeigen
			this.startWindow();
		}

		/// <summary>
		/// klick-event, wenn spielf�hrer auf start button klickt
		/// das spiel wird danach begonnen
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">event</param>
		private void StartSpiel_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.myBDelegate.StartGame(this.gameName);
			}//applikationsfehler aufgetreten
			catch(DynablasterException de)
			{
				Log(de.Message);
			}
		}

		
		/// <summary>
		/// handler f�r button-klick, wenn spieler sich konkret f�r ein 
		/// spiel als teilnahme entschieden hat
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void spielTeilnahme_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.gameName=this.spielauswahl.SelectedItem.ToString();
				Log("es wurde ausgew�hlt: "+gameName);
				myBDelegate.JoinGame(gameName,this.playerName);
				this.waitForStartWindow(gameName);
			}
			//abfangen wenn spiel schon voll besetzt ist
			catch(DynablasterException de)
			{
				Log(de.Message);
			}
		}

		/// <summary>
		/// handler, wenn in combo box ein spiel ausgew�hlt wurde ->
		/// button f�r spielteilnahme wird freigeschaltet
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void spielauswahl_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Log("selected index changed");
			//button f�r teilnahme wird freigeschaltet
			this.spielTeilnahme.Enabled=true;
		}

		/// <summary>
		/// button der bei auswahl der spiele bei der teilnahme aktualisiert, holt
		/// aktuelle angemeldete, aber noch nicht gestartete spiele vom spielserver
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void auswahlAktButton_Click(object sender, System.EventArgs e)
		{
			//chooseGameWindow nochmal laden
			this.chooseGameWindow();
		}

		
		/// <summary>
		/// diese methode wird nach aufruf von Invalidate() implizit aufgerufen
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="args"></param>
		private void repaint(object sender, PaintEventArgs args)
		{
			this.printWorld();
		}

		/// <summary>
		/// methode f�r das testen des remote delegates
		/// </summary>
		/// <param name="s"></param>
		private void testDelegate(string s)
		{
			Log(s +" ist angekommen");
		}
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++++++++++++++++++++ENDE EVENT HANDLER+++++++++++++++++++++++++
		//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


		

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Vom Windows Form-Designer generierter Code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.serverStart = new System.Windows.Forms.Button();
			this.spielEinleiten = new System.Windows.Forms.Button();
			this.spielTeilnahme = new System.Windows.Forms.Button();
			this.spielBeitreten = new System.Windows.Forms.Button();
			this.beitrittZur�ck = new System.Windows.Forms.Button();
			this.einleiten = new System.Windows.Forms.Button();
			this.einleitenZur�ck = new System.Windows.Forms.Button();
			this.weltauswahl = new System.Windows.Forms.ComboBox();
			this.spielauswahl = new System.Windows.Forms.ComboBox();
			this.StartSpiel = new System.Windows.Forms.Button();
			this.dateneingabe = new System.Windows.Forms.Button();
			this.farbauswahl = new System.Windows.Forms.ComboBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.spielerliste = new System.Windows.Forms.Panel();
			this.name4 = new System.Windows.Forms.Label();
			this.name3 = new System.Windows.Forms.Label();
			this.name2 = new System.Windows.Forms.Label();
			this.name1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.auswahlAktButton = new System.Windows.Forms.Button();
			this.spielerliste.SuspendLayout();
			this.SuspendLayout();
			// 
			// richTextBox1
			// 
			this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBox1.Location = new System.Drawing.Point(272, 328);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(352, 136);
			this.richTextBox1.TabIndex = 0;
			this.richTextBox1.Text = "";
			// 
			// serverStart
			// 
			this.serverStart.BackColor = System.Drawing.Color.LimeGreen;
			this.serverStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.serverStart.ForeColor = System.Drawing.Color.Black;
			this.serverStart.Location = new System.Drawing.Point(216, 136);
			this.serverStart.Name = "serverStart";
			this.serverStart.Size = new System.Drawing.Size(176, 112);
			this.serverStart.TabIndex = 1;
			this.serverStart.Text = "Mit Server verbinden";
			this.serverStart.Click += new System.EventHandler(this.serverStart_Click);
			// 
			// spielEinleiten
			// 
			this.spielEinleiten.BackColor = System.Drawing.Color.LightSkyBlue;
			this.spielEinleiten.Location = new System.Drawing.Point(152, 152);
			this.spielEinleiten.Name = "spielEinleiten";
			this.spielEinleiten.Size = new System.Drawing.Size(128, 64);
			this.spielEinleiten.TabIndex = 2;
			this.spielEinleiten.Text = "Neues Spiel einleiten";
			this.spielEinleiten.Click += new System.EventHandler(this.spielEinleiten_Click);
			// 
			// spielTeilnahme
			// 
			this.spielTeilnahme.BackColor = System.Drawing.Color.LightSkyBlue;
			this.spielTeilnahme.Location = new System.Drawing.Point(240, 136);
			this.spielTeilnahme.Name = "spielTeilnahme";
			this.spielTeilnahme.Size = new System.Drawing.Size(160, 104);
			this.spielTeilnahme.TabIndex = 3;
			this.spielTeilnahme.Text = "Am Spiel teilnehmen";
			this.spielTeilnahme.Click += new System.EventHandler(this.spielTeilnahme_Click);
			// 
			// spielBeitreten
			// 
			this.spielBeitreten.BackColor = System.Drawing.Color.LightSkyBlue;
			this.spielBeitreten.Location = new System.Drawing.Point(360, 152);
			this.spielBeitreten.Name = "spielBeitreten";
			this.spielBeitreten.Size = new System.Drawing.Size(120, 64);
			this.spielBeitreten.TabIndex = 4;
			this.spielBeitreten.Text = "Einem Spiel beitreten";
			this.spielBeitreten.Click += new System.EventHandler(this.spielBeitreten_Click);
			// 
			// beitrittZur�ck
			// 
			this.beitrittZur�ck.BackColor = System.Drawing.Color.Red;
			this.beitrittZur�ck.Location = new System.Drawing.Point(304, 168);
			this.beitrittZur�ck.Name = "beitrittZur�ck";
			this.beitrittZur�ck.Size = new System.Drawing.Size(96, 48);
			this.beitrittZur�ck.TabIndex = 5;
			this.beitrittZur�ck.Text = "Zur�ck";
			// 
			// einleiten
			// 
			this.einleiten.BackColor = System.Drawing.Color.LimeGreen;
			this.einleiten.Location = new System.Drawing.Point(304, 96);
			this.einleiten.Name = "einleiten";
			this.einleiten.Size = new System.Drawing.Size(96, 48);
			this.einleiten.TabIndex = 6;
			this.einleiten.Text = "Einleiten";
			// 
			// einleitenZur�ck
			// 
			this.einleitenZur�ck.BackColor = System.Drawing.Color.Red;
			this.einleitenZur�ck.Location = new System.Drawing.Point(304, 168);
			this.einleitenZur�ck.Name = "einleitenZur�ck";
			this.einleitenZur�ck.Size = new System.Drawing.Size(96, 48);
			this.einleitenZur�ck.TabIndex = 7;
			this.einleitenZur�ck.Text = "Zur�ck";
			// 
			// weltauswahl
			// 
			this.weltauswahl.Location = new System.Drawing.Point(128, 96);
			this.weltauswahl.Name = "weltauswahl";
			this.weltauswahl.Size = new System.Drawing.Size(160, 21);
			this.weltauswahl.TabIndex = 8;
			this.weltauswahl.Text = "welt1";
			// 
			// spielauswahl
			// 
			this.spielauswahl.Location = new System.Drawing.Point(56, 168);
			this.spielauswahl.Name = "spielauswahl";
			this.spielauswahl.Size = new System.Drawing.Size(160, 23);
			this.spielauswahl.TabIndex = 9;
			this.spielauswahl.Text = "\'bitte w�hlen\'";
			this.spielauswahl.SelectedIndexChanged += new System.EventHandler(this.spielauswahl_SelectedIndexChanged);
			// 
			// StartSpiel
			// 
			this.StartSpiel.BackColor = System.Drawing.Color.LimeGreen;
			this.StartSpiel.Location = new System.Drawing.Point(296, 128);
			this.StartSpiel.Name = "StartSpiel";
			this.StartSpiel.Size = new System.Drawing.Size(120, 72);
			this.StartSpiel.TabIndex = 10;
			this.StartSpiel.Text = "Start";
			this.StartSpiel.Click += new System.EventHandler(this.StartSpiel_Click);
			// 
			// dateneingabe
			// 
			this.dateneingabe.BackColor = System.Drawing.Color.LimeGreen;
			this.dateneingabe.Location = new System.Drawing.Point(312, 144);
			this.dateneingabe.Name = "dateneingabe";
			this.dateneingabe.Size = new System.Drawing.Size(112, 56);
			this.dateneingabe.TabIndex = 2;
			this.dateneingabe.Text = "Weiter";
			// 
			// farbauswahl
			// 
			this.farbauswahl.Location = new System.Drawing.Point(176, 176);
			this.farbauswahl.Name = "farbauswahl";
			this.farbauswahl.Size = new System.Drawing.Size(121, 21);
			this.farbauswahl.TabIndex = 3;
			this.farbauswahl.Text = "farbe";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(176, 144);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(120, 20);
			this.textBox1.TabIndex = 4;
			this.textBox1.Text = "name";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(112, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(448, 32);
			this.label1.TabIndex = 2;
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// spielerliste
			// 
			this.spielerliste.BackColor = System.Drawing.SystemColors.ControlLight;
			this.spielerliste.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.spielerliste.Controls.Add(this.name4);
			this.spielerliste.Controls.Add(this.name3);
			this.spielerliste.Controls.Add(this.name2);
			this.spielerliste.Controls.Add(this.name1);
			this.spielerliste.Location = new System.Drawing.Point(56, 96);
			this.spielerliste.Name = "spielerliste";
			this.spielerliste.Size = new System.Drawing.Size(200, 160);
			this.spielerliste.TabIndex = 4;
			// 
			// name4
			// 
			this.name4.Location = new System.Drawing.Point(8, 128);
			this.name4.Name = "name4";
			this.name4.Size = new System.Drawing.Size(150, 24);
			this.name4.TabIndex = 3;
			this.name4.Text = "Spieler 4: -";
			// 
			// name3
			// 
			this.name3.Location = new System.Drawing.Point(8, 88);
			this.name3.Name = "name3";
			this.name3.Size = new System.Drawing.Size(150, 24);
			this.name3.TabIndex = 2;
			this.name3.Text = "Spieler 3: -";
			// 
			// name2
			// 
			this.name2.Location = new System.Drawing.Point(8, 48);
			this.name2.Name = "name2";
			this.name2.Size = new System.Drawing.Size(150, 24);
			this.name2.TabIndex = 1;
			this.name2.Text = "Spieler 2: -";
			// 
			// name1
			// 
			this.name1.Location = new System.Drawing.Point(8, 8);
			this.name1.Name = "name1";
			this.name1.Size = new System.Drawing.Size(150, 24);
			this.name1.TabIndex = 0;
			this.name1.Text = "Spieler 1: -";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(56, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(160, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Teilnehmende Spieler :";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(56, 144);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(160, 16);
			this.label3.TabIndex = 10;
			this.label3.Text = "Spiele zur Auswahl :";
			// 
			// auswahlAktButton
			// 
			this.auswahlAktButton.BackColor = System.Drawing.Color.LightYellow;
			this.auswahlAktButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.auswahlAktButton.Location = new System.Drawing.Point(56, 200);
			this.auswahlAktButton.Name = "auswahlAktButton";
			this.auswahlAktButton.Size = new System.Drawing.Size(160, 24);
			this.auswahlAktButton.TabIndex = 10;
			this.auswahlAktButton.Text = "Auswahl aktualisieren";
			this.auswahlAktButton.Click += new System.EventHandler(this.auswahlAktButton_Click);
			// 
			// GameGUI
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(640, 478);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.serverStart);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "GameGUI";
			this.Text = "Game";
			this.spielerliste.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion



//////////////////MAIN-METHODE////////////////////////////////
// 
		public static void Main()
		{
			Application.Run(new GameGUI());
		}

	}
}
