using System;
using System.Drawing;

namespace dynablaster.client.gui.helper
{
	/// <summary>
	/// klasse die einzelne zeichenmodule zeichnet
	/// </summary>
	public class DrawObject
	{
		/// <summary>
		/// zeichnet ein spielobjekt (wand, stein, schatz)
		/// </summary>
		/// <param name="g">zeichenobjekt</param>
		/// <param name="x">x koordinate des spielfeldes (f�ngt bei 0 an)</param>
		/// <param name="y">y koordinate des spielfeldes (f�ngt bei 0 an)</param>
		/// <param name="brush">f�llobjekt</param>
		public static void DrawGameObject(Graphics g, int x, int y, Brush brush)
		{
			//lock, damit kein zeitgleicher zugriff auf zeichenresource
			lock(g)
			{
				//game-object rectangle to draw
				Rectangle rect= Field.GetObjectRectFromPoint(x,y);
				g.FillRectangle(brush,rect);
			}
		}

		/// <summary>
		/// zeichnet das spielitem spieler
		/// </summary>
		/// <param name="g">zeichenobjekt</param>
		/// <param name="x">x koordinate des spielfeldes (f�ngt bei 0 an)</param>
		/// <param name="y">y koordinate des spielfeldes (f�ngt bei 0 an)</param>
		/// <param name="brush">f�llobjekt</param>
		public static void DrawGamePlayer(Graphics g, int x, int y,Brush brush)
		{
			//lock, damit kein zeitgleicher zugriff auf zeichenresource
			lock(g)
			{
				//game-item rectangle to draw
				Rectangle rect=Field.GetPlayerRectFromPoint(x,y);
				g.FillRectangle(brush, rect);
			}
		}

		/// <summary>
		/// zeichnet das spielitem bombe
		/// </summary>
		/// <param name="g">zeichenobjekt</param>
		/// <param name="x">x koordinate des spielfeldes (f�ngt bei 0 an)</param>
		/// <param name="y">y koordinate des spielfeldes (f�ngt bei 0 an)</param>
		/// <param name="brush">f�llobjekt</param>
		public static void DrawGameBomb(Graphics g, int x, int y,Brush brush)
		{
			//lock, damit kein zeitgleicher zugriff auf zeichenresource
			lock(g)
			{
				//game-item rectangle to draw
				Rectangle rect=Field.GetBombRectFromPoint(x,y);
				g.FillRectangle(brush, rect);
			}
		}

		/// <summary>
		/// zeichnet explosion, kurzes aufflackern der felder, die
		/// in bombenreichweite liegen, aufflackern dieser felder etwas greller,
		/// danach wieder normale Game-Object farbe
		/// </summary>
		/// <param name="g">zeichenobjekt</param>
		/// <param name="x">x-koordinate des epizentrums der explosion</param>
		/// <param name="y">y-koordinate des epizentrums der explosion</param>
		/// <param name="reichweite">reichweite der bombe</param>
		public static void DrawExplosion(Graphics g, int x, int y, Brush brush)
		{
			//lock, damit kein zeitgleicher zugriff auf zeichenresource
			lock(g)
			{
				//game-object rectangle to draw
				Rectangle rect= Field.GetObjectRectFromPoint(x,y);
				g.FillRectangle(brush,rect);
			}	
		}
	}
}
