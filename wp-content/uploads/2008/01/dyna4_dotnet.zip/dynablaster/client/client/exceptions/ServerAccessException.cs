using System;

namespace dynablaster.client.exceptions
{
	/// <summary>
	/// Zusammenfassung f�r ServerAccessException.
	/// </summary>
	public class ServerAccessException:Exception
	{
		public ServerAccessException(string mesg):base(mesg)
		{
		
		}
	}
}
