using System;
using System.Drawing;

namespace dynablaster.client.gui.helper
{
	/// <summary>
	/// helper klasse f�r die errechnung der bildschirmkoordinaten 
	/// der zu zeichnenden spielobjekte und spielitems
	/// </summary>
	public class Field
	{
		//STATISCHE FELDER 
		/// <summary>
		/// Breite des Feldes in Bildpunkten
		/// </summary>
		private const int WIDTH_OBJ=35;
		/// <summary>
		/// H�he des Feldes in Bildpunkten
		/// </summary>
		private const int HEIGHT_OBJ=35;

		/// <summary>
		/// Breite des Spielers
		/// </summary>
		private const int WIDTH_PLAYER=15;
		/// <summary>
		/// H�he des Spielers
		/// </summary>
		private const int HEIGHT_PLAYER=15;

		/// <summary>
		/// Breite einer Bombe
		/// </summary>
		private const int WIDTH_BOMB=7;
		/// <summary>
		/// H�he einer Bombe
		/// </summary>
		private const int HEIGHT_BOMB=7;

		/// <summary>
		/// x-Koordinate, wo das Spielfeld anf�ngt
		/// </summary>
		private const int START_X=170;
		/// <summary>
		/// y-Koordinate, wo das Spielfeld anf�ng
		/// </summary>
		private const int START_Y=40;

		//


		/// <summary>
		/// �bersetzt ein x/y-Koordinaten des Spielfeldes in einen
		/// Bildpunkt, damit ein "richtiges" Zeichnen des Spielobjektes m�glich ist
		/// </summary>
		/// <param name="x">Die nummer der Spalte, erste Spalte ist links mit
		/// wert 0</param>
		/// <param name="y">Die Nummer der Spalte, erste Reihe ist oben mit Wert
		/// 0</param>
		/// <returns>Grafikpunkt zum Zeichnen</returns>
		private static Point CalcObjPosFromCoord(int x, int y)
		{
			int pointX, pointY;
			//ausrechnen horizontal
			pointX= START_X+(x*Field.WIDTH_OBJ);
			//ausrechnen vertikal
			pointY= START_Y+(y*Field.HEIGHT_OBJ); 
			return new Point(pointX,pointY);
		}

		
		/// <summary>
		/// �bersetzt ein x/y-Koordinaten des Spielfeldes in einen
		/// Bildpunkt, damit ein "richtiges" Zeichnen des Items Spieler
		/// Dabei sitzt das Item im Zentrum eines Spielobjektes
		/// </summary>
		/// <param name="x">Nummer der Spalte, erste Spalte ist links mit wert
		/// 0</param>
		/// <param name="y">Nummer der Zeile, erste Reihe ist oben mit 
		/// Wert 0</param>
		/// <returns>Grafikpunkt zum Zeichnen</returns>
		private static Point CalcPlayerPosFromCoord(int x, int y)
		{
			int pointX,pointY;
			//X coordinate bekommen, zun�chst spaltenpunkt bekommen
			pointX=START_X+(x*Field.WIDTH_OBJ);
			//jetzt position des item im Spielobjekt selber
			pointX=(int)pointX+WIDTH_OBJ/2-WIDTH_PLAYER/2;
			//Y coordinate bekommen, zun�chst reihenpunkt bekommen
			pointY=START_Y+(y*Field.HEIGHT_OBJ); 
			//jetzt position des item im Spielobjekt selber
			pointY=(int)pointY+HEIGHT_OBJ/2-HEIGHT_PLAYER/2;
			return new Point(pointX,pointY);
		}

		/// <summary>
		/// �bersetzt ein x/y-Koordinaten des Spielfeldes in einen
		/// Bildpunkt, damit ein "richtiges" Zeichnen des Items Bombe.
		/// Dabei sitzt das Item im Zentrum eines Spielobjektes
		/// </summary>
		/// <param name="x">Nummer der Spalte, erste Spalte ist links mit wert
		/// 0</param>
		/// <param name="y">Nummer der Zeile, erste Reihe ist oben mit 
		/// Wert 0</param>
		/// <returns>Grafikpunkt zum Zeichnen</returns>
		private static Point CalcBombPosFromCoord(int x, int y)
		{
			int pointX,pointY;
			//X coordinate bekommen, zun�chst spaltenpunkt bekommen
			pointX=START_X+(x*Field.WIDTH_OBJ);
			//jetzt position des item im Spielobjekt selber
			pointX=(int)pointX+WIDTH_OBJ/2-WIDTH_BOMB/2;
			//Y coordinate bekommen, zun�chst reihenpunkt bekommen
			pointY=START_Y+(y*Field.HEIGHT_OBJ); 
			//jetzt position des item im Spielobjekt selber
			pointY=(int)pointY+HEIGHT_OBJ/2-HEIGHT_BOMB/2;
			return new Point(pointX,pointY);
		}


		
		
		/// <summary>
		/// Erstellt ein Rechteck eines Spielobjektes, welches einen Bereich 
		/// des Fensters zeigt, so dass einfach dieses von Graphics gezeichnet 
		/// bzw. gef�llt werden kann. 
		/// </summary>
		/// <param name="x">Die x-Koordinate des Spielfeldes</param>
		/// <param name="y">Die y-Koordinate des Spielfeldes</param>
		/// <returns>Rechteck, welches von Graphics passend verwendet werden kann</returns>
		public static Rectangle GetObjectRectFromPoint(int x, int y)
		{
			Size size= new Size(Field.WIDTH_OBJ,Field.HEIGHT_OBJ);
			Point p=Field.CalcObjPosFromCoord(x,y);
			return new Rectangle(p,size);
		}


		/// <summary>
		/// Erstellt ein Rechteck f�r einen Spieler an gegebener Koordinate
		/// </summary>
		/// <param name="x">Die x-Koordinate des Spielfeldes</param>
		/// <param name="y">Die y-Koordinate des Spielfeldes</param>
		/// <returns>Rechteck f�r Spielitem</returns>
		public static Rectangle GetPlayerRectFromPoint(int x, int y)
		{
			Size size=new Size(Field.WIDTH_PLAYER,Field.HEIGHT_PLAYER);
			Point p=Field.CalcPlayerPosFromCoord(x,y);
			return new Rectangle(p,size);

		}

		/// <summary>
		/// Erstellt ein Rechteck f�r eine Bombe an gegebener Koordinate
		/// </summary>
		/// <param name="x">Die x-Koordinate des Spielfeldes</param>
		/// <param name="y">Die y-Koordinate des Spielfeldes</param>
		/// <returns>Rechteck f�r Spielitem</returns>
		public static Rectangle GetBombRectFromPoint(int x, int y)
		{
			Size size=new Size(Field.WIDTH_BOMB,Field.HEIGHT_BOMB);
			Point p=Field.CalcBombPosFromCoord(x,y);
			return new Rectangle(p,size);
		}

	}
}
