#$LastChangedRevision: 115 $
#$LastChangedDate: 2006-04-09 00:29:11 +0200 (So, 09 Apr 2006) $ 

import os
import os.path
import re
from xml.dom.minidom import parse

############################################
# NEED TO BE ADDED/ADJUSTED BY YOU!!!
# directory destination where you content files should be generated
# just set the path of your content root, path must not end with '/' !!
DEST='../sample_homepage/content'
#path of cms config file to get all content organization information
CMS_CONFIG='../sample_homepage/cms/config/cms_config.xml'
#
##############################################


#path of php skeleton content file
PHP_SKEL='./php_skel.txt'


#generating all content files, according to cms-config file
#setting
def generateFiles():
     #content item path above content root directory
     for contentItemDestination in getContentItemDestinations():
          generatePHPFile(contentItemDestination)

          
#generating php file. does not overwrite if file exists already ! 
def generatePHPFile(contentPath):
     contentFilePath=DEST+contentPath
     #check if file already created
     if os.path.exists(contentFilePath):
          print '%s exists already. Skipping creation of file...'%(contentFilePath)          
     else:               
          print "Generating: ",contentFilePath          
          createContentFile(contentFilePath)     

def createContentFile(contentFilePath):
     #directories must exist before file is created
     createDirectoryPath(contentFilePath)
     writeTextToFile(getTextOfFile(PHP_SKEL),contentFilePath)          

def createDirectoryPath(filePath):
     if not os.path.exists(os.path.dirname(filePath)):
          os.makedirs(os.path.dirname(filePath))               

def getTextOfFile(fileName):
     fd=open(fileName)
     text=fd.read()
     fd.close()
     return text

def writeTextToFile(text,fileName):
     fd=open(fileName,'w') 
     fd.write(text)
     fd.close()

def checkFileExists(file):
     if not os.path.isfile(file):
          raise IOError("Set File not found: %s",file)                  

#DOM: Document Object Model
def getCMSDOM():
     return parse(CMS_CONFIG)

def getContentItemsDOM():
     return getCMSDOM().getElementsByTagName('item')

#getting content item paths (under content root)
def getContentItemDestinations():
     filePathArray=[]
     #iterate all <item> tags in <contents> part of cms config
     for contentItemDOM in getContentItemsDOM():
          filePathArray.append(getContentItemPath(contentItemDOM))
     return filePathArray

#getting content item path (under content root)
def getContentItemPath(contentItemDOM):
     return contentItemDOM.getAttribute('category')+contentItemDOM.getAttribute('link')+'.php5'

     
#main function 
def createSkeleton():
     #checking neccessary files exist
     checkFileExists(PHP_SKEL)
     checkFileExists(CMS_CONFIG)
     #creating dest dir, where skeletons are
     createDirectoryPath(DEST)     
     #generating all skeleton files 
     generateFiles()         



####################################
##OUTPUT CONVENIENCE FOR USER
def showGlobalSettings():
     print "\n\n+++++++++++++++++++++++++++++++++++"
     print "Using following generator settings:"
     print "Destination of generated content files: %s" %(os.path.abspath(DEST))
     print "PHP skeleton file: %s" %(os.path.abspath(PHP_SKEL))
     print "CMS4_aldana config file: %s" %(os.path.abspath(CMS_CONFIG))
     print "+++++++++++++++++++++++++++++++++++\n\n"
##
##################################

#if called by interpreter directly
if __name__=='__main__':
     #run skeleton generator
     print "Starting generating skeletons..."
     #!!!global settings must be set on top of file!!!
     showGlobalSettings()          
     createSkeleton()
     
     
     
     
     