++++info der ordner+++++

dynaUML/: inhalt dieses ordners ist ein java-applet, wo man im uml-modell rumbrowsen kann 
(�bersichtlicher f�r �berblick als im source code rumzuschauen...). uml-modell zum grossen teil 
abbild der implementierung. 

dynaInfo.pdf: allgemeine Info zur Nutzung und grobe Bugs, die entdeckt, aber nocht nicht 
 bereinigt wurden