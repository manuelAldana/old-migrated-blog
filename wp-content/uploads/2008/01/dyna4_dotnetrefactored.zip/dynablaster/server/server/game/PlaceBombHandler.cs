using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;
using dynablaster.shared_libs.game;

namespace dynablaster.server.game
{
    public class PlaceBombHandler:IPlaceBombHandler
    {
        GameEvent gameEventHandler;
        ExplodeEvent explodeEventHandler;
        GameState gameState;


        public PlaceBombHandler(GameEvent gameEventHandler,ExplodeEvent explodeEvenHandler){
            this.gameEventHandler=gameEventHandler;
            this.explodeEventHandler=explodeEvenHandler;
        }

        public void UpdateGameEventCallbacks(GameEvent gameEvent){
            this.gameEventHandler = gameEvent;
        }

        //bombs exploding arg to be refactored later
        public GameState PlaceBomb(string playerName,GameState gameState,IList bombsExploding)
        {
            this.gameState = gameState;
            Player playerWhoPlacedBomb = gameState.getPlayerByName(playerName);
            //koordinaten des spielers holen
            int x = playerWhoPlacedBomb.getXCoord();
            int y = playerWhoPlacedBomb.getYCoord();
            //�berpr�fen, ob nicht schon eine bombe auf dem feld liegt
            if (this.FieldAlreadyOccupiedByBomb(x, y))
                //application exception an client senden
                throw new DynablasterException("Field already occupied by Bomb!");
            this.gameState.AddBomb(new Bomb(x, y));
            //explosionsroutine (bombe z�nden) starten
            bombsExploding.Add(new BombExplosion(x, y, this.explodeEventHandler));
            //mulitcast to clients
            gameEventHandler(new BombEventArgs(this.gameState));
            //fertig mit place bomb -> return
            return this.gameState;
        }

        private bool FieldAlreadyOccupiedByBomb(int xCoord, int yCoord)
        {
            //menge der bomben durchsuchen
            foreach (Bomb bomb in this.gameState.cachedBombs)
                if (bomb.GetXCoord() == xCoord && bomb.GetYCoord() == yCoord)
                    return true;
            return false;
        }


    }
}
