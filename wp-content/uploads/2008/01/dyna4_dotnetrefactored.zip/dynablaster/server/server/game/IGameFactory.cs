using System;
using System.Collections;
using System.Threading;

using dynablaster.server.game;
using dynablaster.server.game.worlds;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.server.game
{
    public interface IGameFactory
    {
        IGame CreateGame();
    }
}
