﻿using System;

namespace dynablaster.server.game
{
    public interface IGame
    {
        void AddPlayer(string playerName, dynablaster.shared_libs.callbacks.StartEvent startEvent, dynablaster.shared_libs.callbacks.GameEvent gameEvent);
        bool GameFinished();
        string GameName { get; }
        void PlaceBomb(string playerName);
        void PlayerMoveDown(string playerName);
        void PlayerMoveLeft(string playerName);
        void PlayerMoveRight(string playerName);
        void PlayerMoveUp(string playerName);
        void RegisterGame(string gameName, string player, dynablaster.shared_libs.game.gameObjects.Field[,] map, dynablaster.shared_libs.callbacks.JoinEvent joinEvent, dynablaster.shared_libs.callbacks.StartEvent startEvent, dynablaster.shared_libs.callbacks.GameEvent gameEvent);
        void StartGame();
        bool TooFewPlayersJoinedGame();
    }
}
