using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;


namespace dynablaster.server.game
{
    public interface IPlaceBombHandler
    {
        GameState PlaceBomb(string playerName, GameState gameState,IList bombsExploding);
        void UpdateGameEventCallbacks(GameEvent gameEvent);
    }
}
