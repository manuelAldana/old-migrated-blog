using System;
using System.Collections;
using System.Text;


using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;
using dynablaster.shared_libs.game;

namespace dynablaster.server.game
{
    public class PlayerMoveHandler:IPlayerMoveHandler
    {
        private event GameEvent gameEventHandler;
        private GameState gameState;

        public PlayerMoveHandler(GameEvent gameEventHandler){
            this.gameEventHandler = gameEventHandler;
        }

        public void UpdateGameEventCallbacks(GameEvent gameEvent){
            this.gameEventHandler+=gameEvent;
        }

        public GameState PlayerMoveUp(string playerName, GameState gameState){
            return PlayerMove(Player.MOVE_UP, playerName, gameState);
        }

        public GameState PlayerMoveRight(string playerName, GameState gameState){
            return PlayerMove(Player.MOVE_RIGHT, playerName, gameState);
        }

        public GameState PlayerMoveDown(string playerName, GameState gameState){
            return PlayerMove(Player.MOVE_DOWN, playerName, gameState);
        }        

        public GameState PlayerMoveLeft(string playerName, GameState gameState){
            return PlayerMove(Player.MOVE_LEFT, playerName, gameState);
        }

        private GameState PlayerMove(int direction, string playerName, GameState gameState){
            this.gameState = gameState;
            Player player = GetPlayerByName(playerName);
            if (!CanPlayerMove(direction, player))
                throw new DynablasterException("You cannot move, obstacle in your way.");
            player.Move(direction);
            this.gameEventHandler(new PlayerMovedArgs(this.gameState));            
            CheckIfPlayerFoundTreasure(player);
            return gameState;
        }        

        private void CheckIfPlayerFoundTreasure(Player player){
            if (TreasureOnField(player.getXCoord(), player.getYCoord()))
                this.gameEventHandler(new WinnerEventArgs(player, this.gameState));            
        }

        private bool TreasureOnField(int x, int y)
        {
            if (this.gameState.cachedMap[x, y] is Treasure)
                return true;
            return false;
        }

        private Player GetPlayerByName(string playerName)
        {
            foreach (Player player in this.gameState.cachedPlayers)
                if (player.GetName().Equals(playerName))
                    return player;
            return null;
        }

        private bool CanPlayerMove(int direction, Player player)
        {
            if (direction == Player.MOVE_UP)
                return CanPlayerMoveUp(player);
            if (direction == Player.MOVE_RIGHT)
                return CanPlayerMoveRight(player);
            if (direction == Player.MOVE_DOWN)
                return CanPlayerMoveDown(player);
            if (direction == Player.MOVE_LEFT)
                return CanPlayerMoveLeft(player);
            Asserts.codeNotReached("Undefined state: player can only move in 4 directions");
            return false;
        }

        private bool CanPlayerMoveRight(Player player)
        {
            return CanPlayerMove(player.getXCoord() + 1, player.getYCoord());
        }

        private bool CanPlayerMoveUp(Player player)
        {
            return CanPlayerMove(player.getXCoord(), player.getYCoord() - 1);
        }

        private bool CanPlayerMoveLeft(Player player)
        {
            return CanPlayerMove(player.getXCoord() - 1, player.getYCoord());
        }

        private bool CanPlayerMoveDown(Player player)
        {
            return CanPlayerMove(player.getXCoord(), player.getYCoord() + 1);
        }

        private bool CanPlayerMove(int xCoord, int yCoord)
        {
            if (this.GetGameObjectAt(xCoord, yCoord).IsObstacle())
                return false;
            else
                return true;
        }

        private Field GetGameObjectAt(int x, int y)
        {
            return this.gameState.cachedMap[x, y];
        }

    }
}
