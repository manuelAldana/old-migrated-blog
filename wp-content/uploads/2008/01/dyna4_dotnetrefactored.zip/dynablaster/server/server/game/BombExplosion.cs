using System;
using System.Timers;

namespace dynablaster.server.game
{
	
	public delegate void ExplodeEvent(object sender,int x, int y);

    //manages bomb explosions
	public class BombExplosion
	{
		//in ms
		private static int timeToExplode=2000;

		event ExplodeEvent ExplodeEventHandler;
		
		int xEpicenter;
		int yEpicenter;
		//timer for explosion
		Timer timer;

		public BombExplosion(int x, int y, ExplodeEvent ExplodeListeners)
		{
			Console.WriteLine("...and fired!");
			this.ExplodeEventHandler+=ExplodeListeners;
			this.xEpicenter=x;
			this.yEpicenter=y;
			this.timer=new Timer(BombExplosion.timeToExplode);
			this.timer.Elapsed+=new ElapsedEventHandler(this.BombTimeElapsed);
			this.timer.Start();
		}

		private void BombTimeElapsed(object sender, ElapsedEventArgs args)
		{
			Console.WriteLine("bombe explodiert...");
			this.timer.Stop();
			this.ExplodeEventHandler(sender,this.xEpicenter,this.yEpicenter);
		}

	}
}
