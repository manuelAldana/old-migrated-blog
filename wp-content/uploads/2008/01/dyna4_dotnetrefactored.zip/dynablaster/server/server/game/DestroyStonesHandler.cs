
using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;
using dynablaster.shared_libs.game;

namespace dynablaster.server.game
{
    public class DestroyStonesHandler:IDestroyStonesHandler
    {
        private GameEvent gameEventHandler;

        GameState gameState;
        private bool stonesGotDestroyed;

        public DestroyStonesHandler(GameEvent gameEventHandler){
            this.gameEventHandler = gameEventHandler;
        }

        public GameState DestroyStonesInBombRange(int x, int y, int power, GameState gameState){
            this.gameState = gameState;
            this.stonesGotDestroyed = false;
            lock (this.gameState.cachedMap)
            {
                DestroyStonesInLeftBombRange(x, y, power);
                DestroyExistingStonesInRightBombPowerRange(x, y, power);
                DestroyStonesInUpperBombRange(x, y, power);
                DestroyStonesInLowerBombRange(x, y, power);
                if (this.stonesGotDestroyed)
                    gameEventHandler(new MapChangedEventArgs(this.gameState));
            }
            return this.gameState;
        }

        private void DestroyStonesInLowerBombRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++)
            {
                int lowerY = yEpicenter + i;
                //if:only lower field in range
                if (lowerY <= this.gameState.YBound)
                    this.DestroyStoneOnField(xEpicenter, lowerY);
            }
        }

        public void UpdateGameEventCallbacks(GameEvent gameEvent)
        {
            this.gameEventHandler = gameEvent;
        }

        private void DestroyStonesInUpperBombRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++)
            {
                int upperY = yEpicenter - i;
                //only upper fields in range
                if (upperY >= 0)
                    this.DestroyStoneOnField(xEpicenter, upperY);
            }
        }

        private void DestroyStonesInLeftBombRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++)
            {
                int leftX = xEpicenter - i;
                //only left fields in range
                if (leftX >= 0)
                    this.DestroyStoneOnField(leftX, yEpicenter);
            }
        }

        private void DestroyExistingStonesInRightBombPowerRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++)
            {
                int rightX = xEpicenter + i;
                //only right field in range
                if (rightX <= this.gameState.XBound)
                    this.DestroyStoneOnField(rightX, yEpicenter);
            }
        }

        private void DestroyStoneOnField(int x,int y){
            if(gameState.cachedMap[x,y] is Stone){
                this.stonesGotDestroyed = true;
                this.gameState.cachedMap[x, y] = new Way(x, y);
            }
        }

    }
}
