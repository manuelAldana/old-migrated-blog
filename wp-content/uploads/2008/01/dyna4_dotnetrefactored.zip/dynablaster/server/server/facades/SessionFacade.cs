using System;
using System.Collections;
using System.Threading;

using dynablaster.server.game;
using dynablaster.server.game.worlds;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.server.facades
{
	
	// interface to client (is set as Singleton in .Net Remoting), all clients share same object	
	public class SessionFacade : MarshalByRefObject,IFacadeGame,IFacadeMenu
	{
		//all registered, not started games
		private IList gamesRegistered;
		//games started, which are being played, cannot be joined anymore
		private IList gamesStarted;

        private IGameFactory gameFactory;

		public SessionFacade()
		{
			this.gamesRegistered=new ArrayList();
			this.gamesStarted=new ArrayList();
            this.gameFactory = new GameFactory();
		}

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //+++++++++++++++++++MENU MANAGEMENT  +++++++++++++++++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
		//see IFacadeMenu
        public string[] GetAvailableGames()
		{
			lock(this.gamesRegistered)
			{
				string[] gameNames= new string[gamesRegistered.Count];
				int i=0;
				foreach(Game gameRegistered in gamesRegistered){
					gameNames[i]=gameRegistered.GameName;
					i++;
				}
				return gameNames;
			}
		}

        //see IFacadeMenu
		public void JoinGame(string gameName, string player,StartEvent startEvent, GameEvent gameEvent)
		{
			lock(this.gamesRegistered){				
                GetRegisteredGameByName(gameName).AddPlayer(player,startEvent,gameEvent);					
			}
		}

        private IGame GetRegisteredGameByName(string gameName){
            return GetGameByName(this.gamesRegistered, gameName);
        }

        private IGame GetStartedGameByName(string gameName){
            return GetGameByName(this.gamesStarted, gameName);
        }

        private IGame GetGameByName(IList games,string gameName){
            foreach(IGame game in games)
                if (game.GameName.Equals(gameName))
                    return game;
            return null;            
        }

        //see IFacadeMenu
		public void NewGame(string gameName, string playerName, JoinEvent joinEvent, 
											StartEvent startEvent,GameEvent gameEvent){
			lock(this.gamesRegistered){
                if(GetRegisteredGameByName(gameName)!=null){
                    Console.WriteLine(gameName + " Game name exists already.");
					throw new DynablasterException("Game name exists already.");
                }					
                IGame game = this.gameFactory.CreateGame();
                game.RegisterGame(gameName,playerName,(new World1()).GetMap(),joinEvent,startEvent,gameEvent);
				this.gamesRegistered.Add(game);
			}
			LogGamesNotStarted();
		}

        //see IFacadeMenu
		public void StartGame(string game)
		{
			Console.WriteLine("Entering SessionFacade.StartGame({0})",game);
            IGame gameToBeStarted = this.GetRegisteredGameByName(game);
			if(gameToBeStarted.TooFewPlayersJoinedGame())
			    throw new DynablasterException("Not enough players joined.");				
            //a just started game changes state from registered to started
            lock(this){
			    this.gamesRegistered.Remove(gameToBeStarted);
			    this.gamesStarted.Add(gameToBeStarted);
			}
			Console.WriteLine("Spiel {0} wird gestartet",gameToBeStarted.GameName); 
			gameToBeStarted.StartGame();			
			return;			
		}

		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//++++++++++++++++++++END MENU MANAGEMENT+++++++++++++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++


		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++++++++++++GAMEPLAY-STUFF++++++++++++++++++++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		//see IFacadeGame
		public void PlayerMoveUp(string gameName, string playerName){
			lock(this.gamesStarted)
				GetStartedGameByName(gameName).PlayerMoveUp(playerName);								
		}

        //see IFacadeGame
		public void PlayerMoveRight(string gameName, string playerName){
            lock (this.gamesStarted)
                GetStartedGameByName(gameName).PlayerMoveRight(playerName);            
        }

        //see IFacadeGame
		public void PlayerMoveDown(string gameName, string playerName){
			lock(this.gamesStarted)
                    GetStartedGameByName(gameName).PlayerMoveDown(playerName);			
		}

        //see IFacadeGame
		public void PlayerMoveLeft(string gameName, string playerName){
            lock (this.gamesStarted)
                GetStartedGameByName(gameName).PlayerMoveLeft(playerName);            
		}

        //see IFacadeGame
		public void PlaceBomb(string gameName, string playerName){
            lock (this.gamesStarted)
                GetStartedGameByName(gameName).PlaceBomb(playerName);
		}


        //see IFacadeGame
		public void ClientSendsFinishedGame(string gameName){
            IGame gameToBeFinished= GetStartedGameByName(gameName);
            if(gameToBeFinished.GameFinished()){
                Console.WriteLine("No players anymore {0} remove game...", gameToBeFinished.GameName);
    			lock(this.gamesStarted)
                    this.gamesStarted.Remove(gameToBeFinished);
			}
			//anzeigen, welche spiele noch am laufen sind
			this.LogGamesStarted();
		}
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//++++++++++++++++++++END GAMEPLAY-STUFF+++++++++++++++++
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
		
		private void LogGamesNotStarted()
		{
			Console.WriteLine("Following games can be joined:");
			//lock, da collections nicht threadsicher
			lock(this.gamesRegistered)
				foreach(Game gameRegistered in gamesRegistered)
					Console.WriteLine(gameRegistered.GameName);
		}

		private void LogGamesStarted(){
			Console.WriteLine("Following games are being played:");
			lock(this.gamesStarted)
				foreach(Game gameStarted in this.gamesStarted)
					Console.WriteLine(gameStarted.GameName);
		}


		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		//+++++++++++++++ENDE+HELPER ZEUG F�R DEBUG AUSGABEN++++++
		//+++++++++++++++++++
		


	}
}
