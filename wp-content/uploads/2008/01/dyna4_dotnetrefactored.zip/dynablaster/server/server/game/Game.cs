using System;
using System.Collections;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;

namespace dynablaster.server.game
{
    //server side game, mainly delegates two tasks to other objects: 
    // 1) menu-management (register, adding players before gameplay)
    // 2) gamplay management (moving players, exploding bombs etc.)
    public class Game : dynablaster.server.game.IGame
    {

        private static int MAX_PLAYERS = 4;

        private string gameName;
        public string GameName{get{return this.gameName;}}
        
        private event StartEvent StartEventHandler;
        
        private GameplayStage gameplayStage;
        private MenuStage menuStage;

        public Game(){
            this.gameplayStage = new GameplayStage();
            this.menuStage = new MenuStage(MAX_PLAYERS);
        }
        
        public void RegisterGame(string gameName, string player, Field[,] map, JoinEvent joinEvent,
                                    StartEvent startEvent, GameEvent gameEvent){
            this.gameName = gameName;
            this.StartEventHandler += startEvent;
            this.menuStage.RegisterGame(player, map,joinEvent);                      
            this.gameplayStage.AddGameEventCallback(gameEvent);                       
        }        
        
        public bool TooFewPlayersJoinedGame(){
            return this.menuStage.TooFewPlayersJoinedGame();
        }

        public bool GameFinished(){
             return gameplayStage.GameFinished();           
        }
    
        public void StartGame(){
            Console.WriteLine("Game " + this.gameName + " sends StartEvent-Multicast");            
            this.gameplayStage.GameState=GameState.CreateGameInitGameState(this.menuStage.gameMap,this.menuStage.Players);
            //multicast to remote clients
            this.StartEventHandler(new GameInitArgs(this.gameplayStage.GameState));
        }        
        
        public void AddPlayer(string playerName, StartEvent startEvent, GameEvent gameEvent){            
            this.menuStage.AddPlayer(playerName);
            this.gameplayStage.AddGameEventCallback(gameEvent);
            this.StartEventHandler += startEvent;            
        }       

        public void PlayerMoveUp(string playerName){
            this.gameplayStage.PlayerMoveUp(playerName);
        }

        public void PlayerMoveRight(string playerName){
            this.gameplayStage.PlayerMoveRight(playerName);
            
        }

        public void PlayerMoveDown(string playerName){
            this.gameplayStage.PlayerMoveDown(playerName);
        }

        public void PlayerMoveLeft(string playerName){
            this.gameplayStage.PlayerMoveLeft(playerName);
        }

        public void PlaceBomb(string playerName){
            this.gameplayStage.PlaceBomb(playerName);
        }        
     
    }
}
