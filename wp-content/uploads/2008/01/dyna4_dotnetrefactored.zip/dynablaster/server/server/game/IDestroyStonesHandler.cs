
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;

namespace dynablaster.server.game
{
    public interface IDestroyStonesHandler
    {

        GameState DestroyStonesInBombRange(int x, int y, int power,GameState gameState);
        void UpdateGameEventCallbacks(GameEvent gameEvent);
    }
}
