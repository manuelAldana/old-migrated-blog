using System;
using System.Collections;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;

namespace dynablaster.server.game
{
    //manages gameplay of game (moving players, placing bombs)
    public class GameplayStage
    {

        //player, map etc. for game stage
        private GameState gameState;
        public GameState GameState { set { this.gameState = value; } get { return this.gameState; } }        

        private IList bombsExploding;
        
        private event GameEvent gameEventCallbacks;
        private event ExplodeEvent ExplodeEventHandler;

        IPlayerMoveHandler playerMoveHandler;
        IPlaceBombHandler placeBombHandler;
        IKillPlayerHandler killPlayerHandler;
        IDestroyStonesHandler destroyStonesHandler;

        public GameplayStage(){
            this.bombsExploding=new ArrayList();
            this.playerMoveHandler = new PlayerMoveHandler(this.gameEventCallbacks);
            this.ExplodeEventHandler += new ExplodeEvent(this.BombExplodeListener);            
            this.placeBombHandler = new PlaceBombHandler(this.gameEventCallbacks, this.ExplodeEventHandler);
            this.killPlayerHandler = new KillPlayerHandler(this.gameEventCallbacks);
            this.destroyStonesHandler = new DestroyStonesHandler(this.gameEventCallbacks);            
        }

        public void AddGameEventCallback(GameEvent gameEventCallback){
            this.gameEventCallbacks += gameEventCallback;
            this.playerMoveHandler.UpdateGameEventCallbacks(this.gameEventCallbacks);
            this.placeBombHandler.UpdateGameEventCallbacks(this.gameEventCallbacks);
            this.killPlayerHandler.UpdateGameEventCallbacks(this.gameEventCallbacks);
            this.destroyStonesHandler.UpdateGameEventCallbacks(this.gameEventCallbacks); 
        }

        public bool GameFinished(){
            //TO BE DONE: check if treasure was found, then game is finished too!!!!
             if (this.AllPlayersDead())
                 return true;
             return false;           
         }

        private bool AllPlayersDead(){
             if (this.gameState.cachedPlayers.Count== 0)
                 return true;
             return false;
         }

        private void BombExplodeListener(object sender, int x, int y)
        {
            //lock exposion must have exclusive access to game state
            lock (this.gameState)
            {
                Console.WriteLine("Bomb exploded at ({0},{1})", x, y);
                this.RemoveBombFromField(sender, x, y);
                this.KillPlayersHitByBomb(x, y, Bomb.power);
                this.DestroyStonesInBombRange(x, y, Bomb.power);
            }
        }

        public void PlayerMoveUp(string playerName)
        {
            this.gameState = this.playerMoveHandler.PlayerMoveUp(playerName, this.gameState);
        }

        public void PlayerMoveRight(string playerName)
        {
            this.gameState = this.playerMoveHandler.PlayerMoveRight(playerName, this.gameState);
        }

        public void PlayerMoveDown(string playerName)
        {
            this.gameState = this.playerMoveHandler.PlayerMoveDown(playerName, this.gameState);
        }

        public void PlayerMoveLeft(string playerName)
        {
            this.gameState = this.playerMoveHandler.PlayerMoveLeft(playerName, this.gameState);
        }

        public void PlaceBomb(string playerName)
        {
            this.gameState = this.placeBombHandler.PlaceBomb(playerName, this.gameState, this.bombsExploding);
        }

        private void RemoveBombFromField(object sourceExplosion, int x, int y)
        {
            Console.WriteLine("execute bomb explosion...");
            this.gameState.RemoveBombAt(x, y);
            //exploded already, so remove from explosion listener
            this.bombsExploding.Remove(sourceExplosion);
            Console.WriteLine("multicast for bomb explosion");
            this.gameEventCallbacks(new BombEventArgs(this.gameState, new Bomb(x, y)));
        }

        private void KillPlayersHitByBomb(int xEpicenter, int yEpicenter, int bombPower)
        {
            this.gameState = this.killPlayerHandler.KillPlayersHitByBomb(xEpicenter, yEpicenter, bombPower, this.gameState);
        }

        private void DestroyStonesInBombRange(int x, int y, int power)
        {
            this.gameState = this.destroyStonesHandler.DestroyStonesInBombRange(x, y, power, this.gameState);
        }
    }
}
