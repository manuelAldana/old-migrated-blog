
using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;
using dynablaster.shared_libs.game;

namespace dynablaster.server.game
{
    public class KillPlayerHandler:IKillPlayerHandler
    {
        GameEvent gameEventHandler;
        GameState gameState;

        public KillPlayerHandler(GameEvent gameEventHandler){
            this.gameEventHandler = gameEventHandler;
        }

        public GameState KillPlayersHitByBomb(int xEpicenter, int yEpicenter, int bombPower, GameState gameState){
            this.gameState = gameState;
            //lock, otherwise players coordinates could be corrupted by player move events
            lock (this.gameState.cachedPlayers){
                //directly in epicenter
                this.KillPlayersOnPosition(xEpicenter, yEpicenter);
                //and because bomb affecting neighbour fields
                this.KillPlayersInLeftBombPowerRange(xEpicenter, yEpicenter, bombPower);
                this.KillPlayersInRightBombPowerRange(xEpicenter, yEpicenter, bombPower);
                this.KillPlayersInUpperBombPowerRange(xEpicenter, yEpicenter, bombPower);
                this.KillPlayersInLowerBombPowerRange(xEpicenter, yEpicenter, bombPower);                    
            }
            return this.gameState;
        }

        public void UpdateGameEventCallbacks(GameEvent gameEvent){
            this.gameEventHandler = gameEvent;
        }

        private void KillPlayersInLowerBombPowerRange(int xEpicenter,int yEpicenter,int bombPower){
              for (int i = 1; i <= bombPower; i++){
                  int lowerY = yEpicenter + i;
                  //if:only lower field in range
                  if (lowerY <= this.gameState.YBound)
                      this.KillPlayersOnPosition(xEpicenter, lowerY);                                
              }
        }

        private void KillPlayersInUpperBombPowerRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++){
                    int upperY = yEpicenter - i;
                    //only upper fields in range
                    if (upperY >= 0)
                        this.KillPlayersOnPosition(xEpicenter, upperY);                    
            }            
        }

        private void KillPlayersInLeftBombPowerRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++){
                    int leftX = xEpicenter - i;
                    //only left fields in range
                    if (leftX >= 0)
                        this.KillPlayersOnPosition(leftX, yEpicenter);
            }            
        }

        private void KillPlayersInRightBombPowerRange(int xEpicenter, int yEpicenter, int bombPower)
        {
            for (int i = 1; i <= bombPower; i++){
                int rightX = xEpicenter + i;
                //only right field in range
                if (rightX <= this.gameState.XBound)
                    this.KillPlayersOnPosition(rightX, yEpicenter);
            }
        }

        private void KillPlayersOnPosition(int x, int y)
        {            
            foreach (Player player in GetPlayersOnPosition(x, y)){
                this.gameState.RemovePlayer(player);
                Console.WriteLine("Mulitcast that player died.");
                this.gameEventHandler(new PlayerKilledEventArgs(this.gameState,player));
            }
        }

        private IList GetPlayersOnPosition(int xCoord, int yCoord)
        {
            IList playersToBeRemoved = new ArrayList();
            foreach (Player player in this.gameState.cachedPlayers){
                if (player.getXCoord() == xCoord && player.getYCoord() == yCoord)
                    playersToBeRemoved.Add(player);
            }
            return playersToBeRemoved;
        }

        
    }
}



