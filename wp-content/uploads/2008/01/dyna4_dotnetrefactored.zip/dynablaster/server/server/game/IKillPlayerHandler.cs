using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;

namespace dynablaster.server.game
{
    public interface IKillPlayerHandler
    {
        GameState KillPlayersHitByBomb(int xEpicenter, int yEpicenter, int bombPower,GameState gameState);
        void UpdateGameEventCallbacks(GameEvent gameEvent);
    }
}
