using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

using dynablaster.server.facades;

namespace dynablaster.server
{
	/// <summary>
	/// Zusammenfassung f�r Main.
	/// </summary>
	public class ServerStart
	{

		private static string serverConfigFile="server.config";

		public static void Main()
		{
			Console.WriteLine("Server starts.... to stop it press enter ");
			RemotingConfiguration.Configure(serverConfigFile);
			Console.ReadLine();
		}
	}
}
