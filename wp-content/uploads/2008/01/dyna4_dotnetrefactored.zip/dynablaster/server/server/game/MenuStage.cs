using System;
using System.Collections;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.utils;

namespace dynablaster.server.game
{
    //manages the menu part of game (registering, adding players to a game)
    public class MenuStage
    {
        //players, map for menu stage
        public IList players;
        public IList Players{get{return this.players;}}
        public Field[,] gameMap;
        private event JoinEvent joinEventHandler;

        private int XBound{get{return gameMap.GetLength(0) - 1;}}
        private int YBound{get{return gameMap.GetLength(1) - 1;}}
            


        private int maximumPlayers;

        public MenuStage(int maximumPlayers){
            this.maximumPlayers = maximumPlayers;
        }

        public void RegisterGame(string player, Field[,] map,JoinEvent joinEvent)
        {
            this.players = new ArrayList();
            this.players.Add(new Player(1, player, 0, 0));
            this.joinEventHandler += joinEvent;
            this.gameMap = map;
            Console.WriteLine("firing event");
            joinEventHandler(new JoinEventArgs(this.GetPlayerNames()));            
            //this.joinEventHandler(new JoinEventArgs(this.GetPlayerNames()));            
        }

        public void AddJoinCallback(JoinEvent joinEvent){
            this.joinEventHandler=joinEvent;
        }

        public bool TooFewPlayersJoinedGame()
        {

            if (this.players.Count < 2)
                return true;
            else
                return false;
        }

        private bool LimtOfRegisteredPlayersReached()
        {
            if (this.players.Count >= maximumPlayers)
                return true;
            return false;
        }

        //returns player names
        private string[] GetPlayerNames()
        {
            //array of string names
            string[] playerNames = new string[players.Count];
            //for string iteration
            int i = 0;
            //iterate through IList
            foreach (Player p in players)
            {
                Console.WriteLine(p.GetName());
                //copy name to string array
                playerNames[i] = p.GetName();
                //next name
                i++;
            }
            return playerNames;
        }

        public void AddPlayer(string playerName)
        {
            if (LimtOfRegisteredPlayersReached())
                throw new DynablasterException("You cannot join, game is full");
            if (players.Count == 3)
                AddPlayerAsPlayerFour(playerName);
            if (players.Count == 2)
                AddPlayerAsPlayerThree(playerName);
            if (players.Count == 1)
                AddPlayerAsPlayerTwo(playerName);
            Console.WriteLine("Added a player " + playerName+ ". Sending join Event to player, who registered game...");
            //notify client, that player joined
            this.joinEventHandler(new JoinEventArgs(this.GetPlayerNames()));            
        }


        private void AddPlayerAsPlayerFour(string playerName)
        {
            //position bottom right
            players.Add(new Player(4, playerName, XBound, YBound));
        }

        private void AddPlayerAsPlayerThree(string playerName)
        {
            //position bottom left
            players.Add(new Player(3, playerName, 0, YBound));
        }

        private void AddPlayerAsPlayerTwo(string playerName)
        {
            //position top right
            players.Add(new Player(2, playerName, XBound, 0));
        }




    }
}
