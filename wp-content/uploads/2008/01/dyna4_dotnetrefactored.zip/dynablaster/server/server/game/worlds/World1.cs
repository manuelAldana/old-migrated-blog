using System;
using System.Collections;

using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.server.game.worlds
{
	/// <summary>
	/// Einzelne Welt zum Testen, Umsetzung sp�ter vielleicht als xml-datei
	/// </summary>
	public class World1 :World
	{
		public World1()
		{
			x=8;
			y=8;
			//testweld mit 5x4 feldern
			//0-TE SPALTE
			map=new Field[x,y];
			map[0,0]=new Way(0,0);
			map[0,1]=new Wall(0,1);
			map[0,2]=new Wall(0,2);
			map[0,3]=new Wall(0,3);
			map[0,4]=new Way(0,4);
			map[0,5]=new Wall(0,5);
			map[0,6]=new Way(0,6);
			map[0,7]=new Way(0,7);

			//1-TE SPALTE
			map[1,0]=new Way(1,0);
			map[1,1]=new Wall(1,1);
			map[1,2]=new Stone(1,2);
			map[1,3]=new Wall(1,3);
			map[1,4]=new Way(1,4);
			map[1,5]=new Wall(1,5);
			map[1,6]=new Wall(1,6);
			map[1,7]=new Way(1,7);

			//2-TE SPALTE
			map[2,0]=new Way(2,0);
			map[2,1]=new Wall(2,1);
			map[2,2]=new Way(2,2);
			map[2,3]=new Wall(2,3);
			map[2,4]=new Way(2,4);
			map[2,5]=new Stone(2,5);
			map[2,6]=new Stone(2,6);
			map[2,7]=new Stone(2,7);

			//3-TE SPALTE
			map[3,0]=new Way(3,0);
			map[3,1]=new Way(3,1);
			map[3,2]=new Way(3,2);
			map[3,3]=new Way(3,3);
			map[3,4]=new Way(3,5);
			map[3,5]=new Way(3,5);
			map[3,6]=new Way(3,6);
			map[3,7]=new Way(3,7);

			//4-TE SPALTE
			map[4,0]=new Stone(4,0);
			map[4,1]=new Wall(4,1);
			map[4,2]=new Way(4,2);
			map[4,3]=new Stone(4,3);
			map[4,4]=new Wall(4,4);
			map[4,5]=new Wall(4,5);
			map[4,6]=new Way(4,6);
			map[4,7]=new Way(4,7);

			//5-TE SPALTE
			map[5,0]=new Wall(5,0);
			map[5,1]=new Wall(5,1);
			map[5,2]=new Stone(5,2);
			map[5,3]=new Stone(5,3);
			map[5,4]=new Treasure(5,4);
			map[5,5]=new Stone(5,5);
			map[5,6]=new Stone(5,6);
			map[5,7]=new Way(5,7);

			//6-TE SPALTE
			map[6,0]=new Wall(6,0);
			map[6,1]=new Wall(6,1);
			map[6,2]=new Way(6,2);
			map[6,3]=new Wall(6,3);
			map[6,4]=new Stone(6,4);
			map[6,5]=new Wall(6,5);
			map[6,6]=new Wall(6,6);
			map[6,7]=new Way(6,7);

			//7-TE SPALTE
			map[7,0]=new Way(7,0);
			map[7,1]=new Way(7,1);
			map[7,2]=new Way(7,2);
			map[7,3]=new Wall(7,3);
			map[7,4]=new Wall(7,4);
			map[7,5]=new Wall(7,5);
			map[7,6]=new Way(7,6);
			map[7,7]=new Way(7,7);

		}
	}
}
