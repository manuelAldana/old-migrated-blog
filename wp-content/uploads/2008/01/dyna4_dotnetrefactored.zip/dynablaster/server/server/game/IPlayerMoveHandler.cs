using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;

namespace dynablaster.server.game
{
    public interface IPlayerMoveHandler
    {
        GameState PlayerMoveLeft(string playerName,GameState gameState);
        GameState PlayerMoveRight(string playerName, GameState gameState);
        GameState PlayerMoveUp(string playerName, GameState gameState);
        GameState PlayerMoveDown(string playerName, GameState gameState);
        void UpdateGameEventCallbacks(GameEvent gameEvent);
    }
}
