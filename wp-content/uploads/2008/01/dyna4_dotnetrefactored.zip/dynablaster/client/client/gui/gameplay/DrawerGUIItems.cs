using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

using dynablaster.client.gui;
using dynablaster.shared_libs.game.gameObjects;

namespace dynablaster.client.gui.gameplay
{
    public class DrawerGUIItems:IDrawer{

        Graphics painter;

        public DrawerGUIItems(Graphics painter){
            this.painter = painter;
        }

        
        public void DrawGameObject(Field obj, int x, int y){
            if (obj is Stone)
                DrawObject.DrawGameObject(painter, x, y, ColorManagmnt.brushStone);
            if (obj is Wall)
                DrawObject.DrawGameObject(painter, x, y, ColorManagmnt.brushWall);
            if (obj is Way)
                DrawObject.DrawGameObject(painter, x, y, ColorManagmnt.brushWay);
            if (obj is Treasure)
                DrawObject.DrawGameObject(painter, x, y, ColorManagmnt.brushTreasure);
        }
        
        public void DrawGameItem(Object item, int xCoord, int yCoord){            
            //if: item ist ein spieler
            if (item is Player)
            {
                if (((Player)item).GetNumber() == 1)
                {
                    DrawObject.DrawGamePlayer(painter, xCoord, yCoord, ColorManagmnt.brushPlayer1);
                    return;
                }
                if (((Player)item).GetNumber() == 2)
                {
                    DrawObject.DrawGamePlayer(painter, xCoord, yCoord, ColorManagmnt.brushPlayer2);
                    return;
                }
                if (((Player)item).GetNumber() == 3)
                {
                    DrawObject.DrawGamePlayer(painter, xCoord, yCoord, ColorManagmnt.brushPlayer3);
                    return;
                }
                if (((Player)item).GetNumber() == 4)
                {
                    DrawObject.DrawGamePlayer(painter, xCoord, yCoord, ColorManagmnt.brushPlayer4);
                    return;
                }
            }
            //if: item ist eine bombe
            if (item is Bomb)
                DrawObject.DrawGameBomb(painter, xCoord, yCoord, ColorManagmnt.brushBomb);
        }


    }
}
