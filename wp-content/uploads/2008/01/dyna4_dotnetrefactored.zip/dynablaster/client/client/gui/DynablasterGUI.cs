using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;


using dynablaster.client.gui.menu;
using dynablaster.client.gui.gameplay;

using dynablaster.client.logger;
using dynablaster.client.delegates;
using dynablaster.client.exceptions;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.client.gui
{

   

    public delegate void CleanUpGame(string mesg,bool gameFinished);
        
    //main class for dynablaster client GUI 
	public class DynablasterGUI : System.Windows.Forms.Form, ILogger {

        
        //CONTROLS
        protected System.Windows.Forms.Label adviceForUser;
        private System.Windows.Forms.RichTextBox logTextBox;
        private System.ComponentModel.Container components = null;        
                        
        public Graphics painter;
		private bool gameStarted = false;        		
		/// interface to server (see BusinessDelegate-Pattern)
		public IBusinessDelegate businessDelegate;		
		/// callback for receiving start event, when game starts		
		private StartEvent StartGameEventCallback;
        /// callback for other players having joined a game
        public JoinEvent JoinEventCallback;		
		private GameEvent GameEventCallback;       
        
        //local GUI is identified by server by game and player name
        public string playerName = "";
        public string gameName = "";               

        //handles keyboard in game (moving, laying bombs)
        private IKeyboardHandler keyboardHandler;
        //represents menu part (choose name,game,start etc.) of dynablaster
		public MenuWindow windowState;
        //all game events are passed to this one
        private GameHandler gameEventHandler;


        //introduced to make a dummy class possible (for testing issues)
        public DynablasterGUI(String dummyString)
        {
        }

        //entry point constructor of application
        protected DynablasterGUI(){
            //avoids flickering while updating window 
            SetStyle(ControlStyles.DoubleBuffer | ControlStyles.AllPaintingInWmPaint
                        | ControlStyles.UserPaint, true);
            InitializeComponent();
            setEventCallbacks();
            InitMenuWindow();
        }

        private void InitMenuWindow(){
            //menu option for player
            windowState = new EnterPlayerNameAndChooseGameOption(this);
        }

        protected virtual void setEventCallbacks(){
            this.StartGameEventCallback = new StartEvent(StartGameListener);
            this.GameEventCallback = new GameEvent(GameEventListener);
        }

        public void AddControl(Control control){
            Controls.Add(control);
        }

        public void RemoveControl(Control control){
            Controls.Remove(control);
        }

        //callback for EnterTextDialog
        public void SetGameName(string gameName)
        {
            this.gameName = gameName;
        }
        //callback for EnterTextDialog
        public void SetPlayerName(string playerName)
        {
            this.playerName = playerName;
        }

        public void SetAdviceForUserLabelText(string s){
            this.adviceForUser.Text = s;
        }


        private void DisposeAdviceForUser(){
            if(this.adviceForUser!=null)
                this.adviceForUser.Dispose();
        }

        private void AddKeyEventListenerForGame(KeyEventHandler keyEventHandler){
            if (this.logTextBox != null)
                this.logTextBox.KeyDown += keyEventHandler;
        }

        public virtual void initBusinessDelegate(){
            try{
            this.businessDelegate = new ClientDelegate(this.JoinEventCallback, this.StartGameEventCallback, this.GameEventCallback);
            }catch(ServerAccessException sae){
                this.SetAdviceForUserLabelText("Server problems, check, if firewall blocks, network is down or you forgot to the server!!");
            }
        }

        //logging to richt text box 
        public virtual void Log(string s){
            this.logTextBox.AppendText(s + "\r\n");
        }       		

       //method run after GameEvent sent by server -> game is starting now
        public void StartGameListener(GameInitArgs args){
            Log("Game starts now!");
            //to make space for big game field
            DisposeAdviceForUser();
            //key presses are handled now
            this.gameStarted = true;
            Player ownPlayer = args.GameState.getPlayerByName(this.playerName);
            this.keyboardHandler = new KeyboardHandler(this, this.businessDelegate, this.gameName, ownPlayer, args);
            AddKeyEventListenerForGame(new KeyEventHandler(Game_KeyDownListener));            
            this.gameEventHandler = new GameHandler(this,args,ownPlayer);                       
        }

        //all game events come here and are delegated to game event handler object
        private void GameEventListener(DynaEventArgs args){
            this.gameEventHandler.HandleGameEvent(args);
        }	
        
        
        public void CleanUpGame(string mesg,bool gameFinished){
			Log(mesg);
			//remove game key event handler, so no actions are fired to server
			this.logTextBox.KeyDown-=new KeyEventHandler(this.Game_KeyDownListener);
            //player should wait until game is finished (treasure found or all players dead)
			if(gameFinished){
				//notify server to disconnect
				this.businessDelegate.ClientSendFinishedGame(this.gameName);				
				Log("Please press 'Enter' to exit finished game.");
				//callback for closing local GUI 
				this.logTextBox.KeyDown+=new KeyEventHandler(this.FinishedGame_KeyDownListener);
			}
		}
		
		private void Game_KeyDownListener(object sender, KeyEventArgs e){
            //keys must only processed when game has started
            if (!this.gameStarted)
                return;
            try{
                this.keyboardHandler.HandleKeyEvent(e);
            }catch(DynablasterException de){                
                Log(de.Message);
            }            
		}
		
		private void FinishedGame_KeyDownListener(object sender, KeyEventArgs args){
			if(args.KeyCode==Keys.Enter)
				//close GUI window
				this.Close();
		}				

		
		// clean up stuff
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Vom Windows Form-Designer generierter Code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		protected virtual void InitializeComponent()
		{
            this.logTextBox = new System.Windows.Forms.RichTextBox();
            this.adviceForUser = new System.Windows.Forms.Label();
            
            this.SuspendLayout();
        
            // 
            // main window
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(640, 478);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "GameGUI";
            this.Text = "Game";
            this.Load += new System.EventHandler(this.GameGUI_Load);        

            this.adviceForUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adviceForUser.Location = new System.Drawing.Point(112, 32);
            this.adviceForUser.Name = "label1";
            this.adviceForUser.Size = new System.Drawing.Size(448, 32);
            this.adviceForUser.TabIndex = 2;
            this.adviceForUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;           
            
            this.logTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logTextBox.Location = new System.Drawing.Point(272, 328);
            this.logTextBox.Name = "richTextBox1";
            this.logTextBox.Size = new System.Drawing.Size(352, 136);
            this.logTextBox.TabIndex = 0;
            this.logTextBox.Text = "";            
            
            Controls.Add(this.logTextBox);
            Controls.Add(this.adviceForUser);            

            this.ResumeLayout(false);
		}
		#endregion



//////////////////MAIN-METHODE////////////////////////////////
// 
		public static void Main()
		{
			Application.Run(new DynablasterGUI());
		}

        private void GameGUI_Load(object sender, EventArgs e)
        {

        }

	}
}
