using System;
using System.Collections.Generic;
using System.Text;



using dynablaster.client.logger;


namespace dynablaster.client.gui.menu
{
    public class EnterPlayerNameAndChooseGameOption : MenuWindow
    {

        private System.Windows.Forms.Button joinGame;
        private System.Windows.Forms.Button createNewGame;
        

        public EnterPlayerNameAndChooseGameOption(DynablasterGUI parentWindow)
            : base(parentWindow)
        {
            InitControls();
            AddControlsToParentWindow();
            parentWindow.SetAdviceForUserLabelText("Welcome to Dynablaster for .Net");
            EnterTextDialog dialog = new EnterTextDialog(parentWindow.SetPlayerName, EnterTextDialog.LABEL_TEXT_ENTER_PLAYER_NAME);
            parentWindow.SetAdviceForUserLabelText("Hi " + parentWindow.playerName + ", please choose to init a new game or to join one:");
        }

        private void AddControlsToParentWindow()
        {
            parentWindow.AddControl(this.createNewGame);
            parentWindow.AddControl(this.joinGame);
        }

        private void InitControls()
        {
            this.createNewGame = new System.Windows.Forms.Button();
            this.joinGame = new System.Windows.Forms.Button();
            this.joinGame.BackColor = System.Drawing.Color.LightSkyBlue;
            this.joinGame.Location = new System.Drawing.Point(360, 152);
            this.joinGame.Name = "gameJoin";
            this.joinGame.Size = new System.Drawing.Size(120, 64);
            this.joinGame.TabIndex = 4;
            this.joinGame.Text = "Join a game";
            this.joinGame.UseVisualStyleBackColor = false;
            this.joinGame.Click += new System.EventHandler(this.JoinGame_Click);
            this.createNewGame.BackColor = System.Drawing.Color.LightSkyBlue;
            this.createNewGame.Location = new System.Drawing.Point(152, 152);
            this.createNewGame.Name = "spielEinleiten";
            this.createNewGame.Size = new System.Drawing.Size(128, 64);
            this.createNewGame.TabIndex = 2;
            this.createNewGame.Text = "Create new game";
            this.createNewGame.UseVisualStyleBackColor = false;
            this.createNewGame.Click += new System.EventHandler(this.CreateNewGame_Click);
        }

        //when player clicks option to join a game
        private void JoinGame_Click(object sender, System.EventArgs e)
        {
            RemoveControls();
            parentWindow.windowState = new ChooseGameToJoin(parentWindow);
        }

        private void CreateNewGame_Click(object sender, System.EventArgs e)
        {
            RemoveControls();
            parentWindow.windowState = new EnterGameNameAndWaitForJoiners(parentWindow);
        }
        private void RemoveControls()
        {
            parentWindow.RemoveControl(this.createNewGame);
            parentWindow.RemoveControl(this.joinGame);
        }
    }


}
