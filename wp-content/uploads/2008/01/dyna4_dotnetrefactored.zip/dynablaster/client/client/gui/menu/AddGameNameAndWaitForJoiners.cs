using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.shared_libs.exceptions;
using dynablaster.client.exceptions;

using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.utils;

namespace  dynablaster.client.gui.menu
{
    public class EnterGameNameAndWaitForJoiners : MenuWindow
    {


        private System.Windows.Forms.Button buttonStartGame;
        private System.Windows.Forms.Panel playersList;
        private System.Windows.Forms.Label labelJoinedPlayers;
        private System.Windows.Forms.Label playerName1;
        private System.Windows.Forms.Label playerName2;
        private System.Windows.Forms.Label playerName3;
        private System.Windows.Forms.Label playerName4;

        public string GetPlayerName(int playerNumber)
        {
            switch (playerNumber)
            {
                case 1: return playerName1.Text;
                case 2: return playerName2.Text;
                case 3: return playerName3.Text;
                case 4: return playerName4.Text;
            }
            Asserts.codeNotReached("number range for players not correct");
            return null;
        }


        //for dummy/testing purposes             
        public EnterGameNameAndWaitForJoiners() { InitControls(); }


        public EnterGameNameAndWaitForJoiners(DynablasterGUI parentWindow)
            : base(parentWindow){
            parentWindow.JoinEventCallback += new JoinEvent(UpdateJoinPlayers);
            //establish server connection
            parentWindow.initBusinessDelegate();
            EnterTextDialog dialog = new EnterTextDialog(new setTextCallback(parentWindow.SetGameName), EnterTextDialog.LABEL_TEXT_ENTER_GAME_NAME);
            try{
                //register game at server
                parentWindow.businessDelegate.NewGame(parentWindow.gameName, parentWindow.playerName);
            }//game name exists already
            catch (DynablasterException de){
                parentWindow.Log(de.Message);
                //try again to enter other game name
                //TO BE SOLVED TO LOOP FOR ENTERING NEW NAME
            }catch(ServerAccessException sae){
                parentWindow.SetAdviceForUserLabelText("Server problems, check, if firewall blocks, network is down or you forgot to start the server!!");
                return;
            }
            parentWindow.SetAdviceForUserLabelText("Following game is going to start soon: " + parentWindow.gameName+
                                                                        ". Remember that a game can only start with two players at least.");
            InitControls();
            AddControlsToParentWindow();
        }


        private void AddControlsToParentWindow()
        {
            parentWindow.AddControl(labelJoinedPlayers);
            parentWindow.AddControl(playersList);
            parentWindow.AddControl(buttonStartGame);
        }

        private void InitControls()
        {
            this.playersList = new System.Windows.Forms.Panel();
            this.buttonStartGame = new System.Windows.Forms.Button();
            this.labelJoinedPlayers = new System.Windows.Forms.Label();
            this.playerName4 = new System.Windows.Forms.Label();
            this.playerName3 = new System.Windows.Forms.Label();
            this.playerName2 = new System.Windows.Forms.Label();
            this.playerName1 = new System.Windows.Forms.Label();
            this.playersList.SuspendLayout();
            // 
            // label2
            // 
            this.labelJoinedPlayers.Location = new System.Drawing.Point(56, 80);
            this.labelJoinedPlayers.Name = "label2";
            this.labelJoinedPlayers.Size = new System.Drawing.Size(160, 16);
            this.labelJoinedPlayers.TabIndex = 3;
            this.labelJoinedPlayers.Text = "Currently joined players:";
            // 
            // StartSpiel
            // 
            this.buttonStartGame.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonStartGame.Location = new System.Drawing.Point(296, 128);
            this.buttonStartGame.Name = "StartSpiel";
            this.buttonStartGame.Size = new System.Drawing.Size(120, 72);
            this.buttonStartGame.TabIndex = 10;
            this.buttonStartGame.Text = "Start";
            this.buttonStartGame.UseVisualStyleBackColor = false;
            this.buttonStartGame.Click += new System.EventHandler(this.StartGame_Click);
            // 
            // spielerliste
            // 
            this.playersList.BackColor = System.Drawing.SystemColors.ControlLight;
            this.playersList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.playersList.Controls.Add(this.playerName4);
            this.playersList.Controls.Add(this.playerName3);
            this.playersList.Controls.Add(this.playerName2);
            this.playersList.Controls.Add(this.playerName1);
            this.playersList.Location = new System.Drawing.Point(56, 96);
            this.playersList.Name = "spielerliste";
            this.playersList.Size = new System.Drawing.Size(200, 160);
            this.playersList.TabIndex = 4;
            // 
            // name4
            // 
            this.playerName4.Location = new System.Drawing.Point(8, 128);
            this.playerName4.Name = "name4";
            this.playerName4.Size = new System.Drawing.Size(150, 24);
            this.playerName4.TabIndex = 3;
            this.playerName4.Text = "Spieler 4: -";
            // 
            // name3
            // 
            this.playerName3.Location = new System.Drawing.Point(8, 88);
            this.playerName3.Name = "name3";
            this.playerName3.Size = new System.Drawing.Size(150, 24);
            this.playerName3.TabIndex = 2;
            this.playerName3.Text = "Spieler 3: -";
            // 
            // name2
            // 
            this.playerName2.Location = new System.Drawing.Point(8, 48);
            this.playerName2.Name = "name2";
            this.playerName2.Size = new System.Drawing.Size(150, 24);
            this.playerName2.TabIndex = 1;
            this.playerName2.Text = "Spieler 2: -";
            // 
            // name1
            // 
            this.playerName1.Location = new System.Drawing.Point(8, 8);
            this.playerName1.Name = "name1";
            this.playerName1.Size = new System.Drawing.Size(150, 24);
            this.playerName1.TabIndex = 0;
            this.playerName1.Text = "Spieler 1: -";
            this.playersList.ResumeLayout(false);
        }

        //listener for updating players (in players list), who just joined the game
        public void UpdateJoinPlayers(JoinEventArgs joinEventArgs)
        {
            if (joinEventArgs.OnePlayerJoined())
                ShowOnePlayer(joinEventArgs.GetPlayerNames());
            if (joinEventArgs.TwoPlayersJoined())
                ShowTwoPlayers(joinEventArgs.GetPlayerNames());
            if (joinEventArgs.ThreePlayersJoined())
                ShowThreePlayers(joinEventArgs.GetPlayerNames());
            if (joinEventArgs.FourPlayersJoined())
                ShowFourPlayers(joinEventArgs.GetPlayerNames());
        }

        private void ShowOnePlayer(string[] playerNames)
        {
            this.playerName1.Text = "Player 1: " + playerNames[0];
        }
        private void ShowTwoPlayers(string[] playerNames)
        {
            this.playerName2.Text = "Player 2: " + playerNames[1];
            ShowOnePlayer(playerNames);
        }
        private void ShowThreePlayers(string[] playerNames)
        {
            this.playerName3.Text = "Player 3: " + playerNames[2];
            ShowTwoPlayers(playerNames);
        }
        private void ShowFourPlayers(string[] playerNames)
        {
            this.playerName4.Text = "Player 4: " + playerNames[3];
            ShowThreePlayers(playerNames);
        }

        private void StartGame_Click(object sender, System.EventArgs e)
        {
            try
            {
                parentWindow.businessDelegate.StartGame(parentWindow.gameName);
                RemoveControls();
            }
            catch (DynablasterException de)
            {
                parentWindow.Log(de.Message);
            }
        }

        private void RemoveControls(){
            this.playersList.Dispose();
            this.buttonStartGame.Dispose();
            this.labelJoinedPlayers.Dispose();            
        }

    }
}
