using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;



using dynablaster.client.logger;
using dynablaster.client.delegates;
using dynablaster.client.exceptions;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.client.gui.gameplay

{
    public interface IKeyboardHandler
    {

        void HandleKeyEvent(KeyEventArgs keyArgs);
    }
}
