using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;



using dynablaster.client.logger;
using dynablaster.client.delegates;
using dynablaster.client.exceptions;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.client.gui.gameplay
{
            
    public class GameHandler
    {
        public static bool GAME_FINISHED = true;
        public static bool GAME_NOT_FINISHED = false;

        Player ownPlayer;
        CleanUpGame CleanUpGame;
        UpdateGameFieldCallback updateGameField;
        IDrawerExplosion drawerExplosion;
        ILogger logger;
        
                
        public GameHandler(DynablasterGUI gameGUI,GameInitArgs gameInitArgs,Player ownPlayer){
            //gameGUI too offers logging functionality
            this.logger = gameGUI;
            this.CleanUpGame = gameGUI.CleanUpGame;
            this.ownPlayer = ownPlayer;
            this.drawerExplosion = DrawerExplosion.CreateDrawerExplosionGameStart(gameGUI.CreateGraphics(), gameInitArgs);
            this.updateGameField = UpdateGameField.CreateGUIDrawerUpdateField(gameGUI).Update;
            //paint stuff for the first time
            updateGameField(gameInitArgs.GameState);
        }

        public void HandleGameEvent(DynaEventArgs args){
            lock(this){
                if (args is PlayerMovedArgs)
                    this.PlayerMovedHandler((PlayerMovedArgs)args);
                //bomb was layed or exploded
                if (args is BombEventArgs)
                    this.BombEventHandler((BombEventArgs)args);
                //maps looks different 
                if (args is MapChangedEventArgs)
                    this.MapChangedEventHandler((MapChangedEventArgs)args);
                //a player has won
                if (args is WinnerEventArgs)
                    this.WinnerEventHandler((WinnerEventArgs)args);
                //if: es handelt sich um ein event, wo ein spieler gestorben ist
                if (args is PlayerKilledEventArgs)
                    this.PlayerKilledEventHandler((PlayerKilledEventArgs)args);            
            }
        }

        public void PlayerMovedHandler(PlayerMovedArgs args)
        {
            //own player dates synchronize with server side state 
            SynchronizeOwnPlayer(args.getGameState().getPlayerByName(this.ownPlayer.GetName()));
            updateGameField(args.getGameState());
        }

        private void SynchronizeOwnPlayer(Player player)
        {
            this.ownPlayer.setXCoord(player.getXCoord());
            this.ownPlayer.setYCoord(player.getYCoord());
        }

        //bomb event either bomb layed down or bomb exploded 
        private void BombEventHandler(BombEventArgs args)
        {
            this.logger.Log("Received bomb event.");
            if (args.BombExploded())
            {
                this.logger.Log("Bomb exploded.");
                this.drawerExplosion.DrawExplosion(args.GetBombExploded());
                //sleep, so something can be seen on GUI 
                Thread.Sleep(550);
            }
            updateGameField(args.getGameState());
        }

        private void MapChangedEventHandler(MapChangedEventArgs args)
        {
            this.logger.Log("Received MapChangedEvent.");
            updateGameField(args.getGameState());
        }

        private void WinnerEventHandler(WinnerEventArgs args)
        {
            this.logger.Log("Received WinnerEvent.");
            if (OwnPlayerIsWinner(args.GetWinner()))
                this.CleanUpGame("Congrats you've won the game!", GAME_FINISHED);
            else
                this.CleanUpGame("Sorry, " + args.GetWinner().GetName() + " was quicker in finding the treasure.", GAME_FINISHED);
        }

        private void PlayerKilledEventHandler(PlayerKilledEventArgs args)
        {
            this.updateGameField(args.getGameState());
            //all players are dead 
            if (args.getGameState().AllPlayersDead())
                this.CleanUpGame("Game finished!! All players including you are dead.", GAME_FINISHED);
            //only one player died
            else
                if (OwnPlayerIsDead(args.GetKilledPlayer()))
                    this.CleanUpGame("You got killed, please wait for the game to finish.", GAME_NOT_FINISHED);
        }

        private bool OwnPlayerIsDead(Player killedPlayer)
        {
            return IsOwnPlayer(killedPlayer);
        }

        private bool OwnPlayerIsWinner(Player winner)
        {
            return IsOwnPlayer(winner);
        }

        private bool IsOwnPlayer(Player player)
        {
            if (player.Equals(this.ownPlayer))
                return true;
            return false;
        }
    }
}