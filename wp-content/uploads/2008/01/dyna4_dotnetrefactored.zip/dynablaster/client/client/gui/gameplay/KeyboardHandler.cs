using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;



using dynablaster.client.logger;
using dynablaster.client.delegates;
using dynablaster.client.exceptions;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.utils;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.game.gameObjects;


namespace dynablaster.client.gui.gameplay
{
    public class KeyboardHandler:IKeyboardHandler
    {



        private ILogger logger;
        private IBusinessDelegate myBDelegate;
        private string gameName;
        private Player ownPlayer;
        private int xBound;
        private int yBound;

        public KeyboardHandler(ILogger logger, IBusinessDelegate businessDelegate, string gameName, Player ownPlayer, GameInitArgs args):
            this(logger, businessDelegate, gameName, ownPlayer, args.XBound, args.YBound){
        }        

        public KeyboardHandler(ILogger logger,IBusinessDelegate businessDelegate,string gameName,Player ownPlayer,int xBound,int yBound){
            this.logger = logger;
            this.myBDelegate = businessDelegate;
            this.gameName = gameName;
            this.ownPlayer=ownPlayer;
            this.xBound = xBound;
            this.yBound = yBound;
        }        

        public void HandleKeyEvent(KeyEventArgs args)
        {
            if (PlayerWantsToMove(args.KeyCode))
                MovePlayer(args.KeyCode);
            if (PlayerPlacedBomb(args))
                this.myBDelegate.PlaceBomb(this.gameName, this.ownPlayer.GetName());
        }            

        private bool PlayerPlacedBomb(KeyEventArgs args){
            if(args.KeyCode==Keys.Enter)
                return true;
            return false;
        }

        private bool PlayerWantsToMove(Keys keyCode){
            if(keyCode==Keys.Left)
                return true;
            if(keyCode==Keys.Right)
                return true;
            if(keyCode==Keys.Up)
                return true;
            if(keyCode==Keys.Down)
                return true;
            //other key pressed as cursor keys
            return false;
        }
        
        private void MovePlayer(Keys keyCode){
            if(PlayerWantsToMoveOutsideGameField(keyCode)){
                this.logger.Log("You cannot move outside game field.");
                return;
            }
            if(keyCode==Keys.Left)
                this.myBDelegate.PlayerMoveLeft(this.gameName,this.ownPlayer.GetName());
            if(keyCode==Keys.Right)
                this.myBDelegate.PlayerMoveRight(this.gameName, this.ownPlayer.GetName());
            if(keyCode==Keys.Up)
                this.myBDelegate.PlayerMoveUp(this.gameName, this.ownPlayer.GetName());
            if(keyCode==Keys.Down)
                this.myBDelegate.PlayerMoveDown(this.gameName, this.ownPlayer.GetName());            
        }
        
        private bool PlayerWantsToMoveOutsideGameField(Keys keyCode){
            if (keyCode== Keys.Up)
                if (this.ownPlayer.getYCoord() - 1 < 0)
                    return true;                
            if (keyCode== Keys.Right)
                if (this.ownPlayer.getXCoord() + 1 > this.xBound)                    
                    return true;                
            if (keyCode== Keys.Down)
                if (this.ownPlayer.getYCoord() + 1 > this.yBound)
                    return true;                
            if (keyCode== Keys.Left)
                if (this.ownPlayer.getXCoord() - 1 < 0)
                    return true;                
            return false;
        }

    }
}
