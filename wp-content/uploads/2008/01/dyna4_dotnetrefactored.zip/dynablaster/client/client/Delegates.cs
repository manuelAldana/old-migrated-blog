using System;
using System.Collections.Generic;
using System.Text;


using dynablaster.shared_libs.game;

namespace dynablaster.client.gui
{
    
    public delegate void UpdateGameFieldCallback(GameState gameState); 

    
}
