using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;

namespace dynablaster.client.gui.gameplay
{
    public interface IDrawer
    {

        void DrawGameObject(Field obj, int x, int y);

        void DrawGameItem(Object item, int xCoord, int yCoord);
        

    }
}
