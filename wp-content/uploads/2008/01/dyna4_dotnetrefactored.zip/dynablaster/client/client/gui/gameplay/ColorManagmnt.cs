using System;
using System.Drawing;

namespace dynablaster.client.gui.gameplay
{
	
	public class ColorManagmnt
	{
		
		//static game-objects
		public static Brush brushWay= new SolidBrush(Color.Ivory);
		public static Brush brushStone= new SolidBrush(Color.LightGray);
		public static Brush brushWall= new SolidBrush(Color.Gray);
		public static Brush brushTreasure= new SolidBrush(Color.Yellow);

		//dynamic game-items
		public static Brush brushBomb= new SolidBrush(Color.Black);
		public static Brush brushPlayer1=new SolidBrush(Color.Red);
		public static Brush brushPlayer2=new SolidBrush(Color.Blue);
		public static Brush brushPlayer3=new SolidBrush(Color.Green);
		public static Brush brushPlayer4=new SolidBrush(Color.LightPink);

		//explosion color
		public static Brush brushExplosion=new SolidBrush(Color.LightYellow);
		public static Brush brushEpicenter=new SolidBrush(Color.MistyRose);
	}
}
