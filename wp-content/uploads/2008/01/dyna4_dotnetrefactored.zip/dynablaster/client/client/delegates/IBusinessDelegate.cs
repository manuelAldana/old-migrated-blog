using System;

using dynablaster.shared_libs.callbacks;


namespace dynablaster.client.delegates
{

	//business delegate hides network connection protocol from GUI
	public interface IBusinessDelegate
	{

        //PRE: game exists
        //POST: player with name and his events were added to game        
		void JoinGame(string game, string player);
        //QUERY : return all games which have not started yet
		string[] GetAvailableGames();
        //PRE: game does not exist yet
        //POST: game is registered with name in menu stage, player with his callbacks were added to game 
		void NewGame(string game, string player);
        //PRE: game exists
        //POST: game is removed from list of menu games, and added to list of started games		
		void StartGame(string game);
		//
		//++++++++END METHODS FOR MENU +++++++++++++++++++


		//+++++++++METHODS FOR GAMEPLAY++++++++++++++++++++++++
		//

        //PRE: game and player (as names) exist, move up cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
		void PlayerMoveUp(string game, string player);
        //PRE: game and player (as names) exist, move right cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
		void PlayerMoveRight(string game, string player);
        //PRE: game and player (as names) exist, move down cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
        void PlayerMoveDown(string game, string player);
        //PRE: game and player (as names) exist, move left cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
        void PlayerMoveLeft(string game, string player);
        //PRE: player and game (as names) exist, players stands on non obstacle field
        //POST: bomb is placed on coordinates of player 
		void PlaceBomb(string game, string player);

        //PRE: game name exists
        //POST: game is removed from started games list XOR is still kept in started games list
		void ClientSendFinishedGame(string game);


	}
}
