using System;


using dynablaster.client.gui;

namespace dynablaster.client.logger
{
    public interface ILogger
    {
        void Log(string s);
    }       

    public class DummyLogger : ILogger{
        public void Log(string s){
        }        
    }
}
