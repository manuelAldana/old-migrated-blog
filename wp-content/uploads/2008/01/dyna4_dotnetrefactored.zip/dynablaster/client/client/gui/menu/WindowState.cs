using System;
using System.Collections.Generic;
using System.Text;

namespace dynablaster.client.gui.menu
{
    public abstract class MenuWindow
    {
        
        protected DynablasterGUI parentWindow;
        
        protected void Log(string s){
            parentWindow.Log(s);
        }
       
        //for dummy purposes
        public MenuWindow(){}
        
        public MenuWindow(DynablasterGUI parentWindow){
            //all window states know about their main gui object
            this.parentWindow = parentWindow;
        }
    }
}
