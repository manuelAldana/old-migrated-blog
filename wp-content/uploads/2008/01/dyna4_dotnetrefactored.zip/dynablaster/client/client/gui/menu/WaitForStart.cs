using System;
using System.Collections.Generic;
using System.Text;


namespace dynablaster.client.gui.menu
{
    public class WaitForStart : MenuWindow
    {

        public WaitForStart(DynablasterGUI parentWindow)
            : base(parentWindow){
            parentWindow.SetAdviceForUserLabelText("Please wait until game owner starts game: " + parentWindow.gameName);
        }
    }
}
