using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

using dynablaster.client.gui;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;

namespace dynablaster.client.gui.gameplay
{
    public class DrawerExplosion:IDrawerExplosion
    {

        public static DrawerExplosion CreateDrawerExplosionGameStart(Graphics painter,GameInitArgs gameInitArgs){
            return new DrawerExplosion(painter,gameInitArgs.XBound,gameInitArgs.YBound);
        }

        Graphics painter;
        int xBound;
        int yBound;

        public DrawerExplosion(Graphics painter,int xBound, int yBound){
            this.painter = painter;
            this.xBound = xBound;
            this.yBound = yBound;
        }

        public void DrawExplosion(Bomb bomb){
            DrawExplosion(bomb.GetXCoord(), bomb.GetYCoord(), Bomb.power);
        }

        private void DrawExplosion(int x, int y, int bombPower){
            DrawBombEpicenter(x, y);
            DrawExplosionOfEpicenterRange(x, y, bombPower);
        }

        private void DrawExplosionOfEpicenterRange(int x, int y, int bombPower){
            for (int i = 1; i <= bombPower; i++){
                //temps for neighbour fields
                int leftX, rightX, upperY, lowerY;
                leftX = x - i;
                rightX = x + i;
                upperY = y - i;
                lowerY = y + i;
                // 'if' statements check, that explosions don't get drawn outside of border
                if (upperY >= 0)
                    DrawObject.DrawExplosion(this.painter, x, upperY, ColorManagmnt.brushExplosion);
                if (rightX <= xBound)
                    DrawObject.DrawExplosion(this.painter, rightX, y, ColorManagmnt.brushExplosion);
                if (lowerY <= yBound)
                    DrawObject.DrawExplosion(this.painter, x, lowerY, ColorManagmnt.brushExplosion);
                if (leftX >= 0)
                    DrawObject.DrawExplosion(this.painter, leftX, y, ColorManagmnt.brushExplosion);
            }
        }

        private void DrawBombEpicenter(int xEpicenter, int yEpicenter){
            DrawObject.DrawGameObject(painter, xEpicenter, yEpicenter, ColorManagmnt.brushEpicenter);
        }




    }
}
