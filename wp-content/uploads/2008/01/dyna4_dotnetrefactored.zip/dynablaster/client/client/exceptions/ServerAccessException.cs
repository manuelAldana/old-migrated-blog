using System;

namespace dynablaster.client.exceptions
{
	//any technical exceptions from server (network, server not started etc.)
	public class ServerAccessException:Exception
	{
		public ServerAccessException(string mesg):base(mesg)
		{
		
		}
	}
}
