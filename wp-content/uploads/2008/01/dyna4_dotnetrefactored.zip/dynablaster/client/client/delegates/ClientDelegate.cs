using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Net.Sockets;

using dynablaster.client.exceptions;
using dynablaster.shared_libs.server.facades;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.exceptions;
using dynablaster.client.gui;

namespace dynablaster.client.delegates
{
	
    //hides server details from gui, wraps exceptions
	public class ClientDelegate : IBusinessDelegate
	{
		//network endpoint
		private static string address="localhost:55555";
		private IFacadeMenu menuServer;
		private IFacadeGame gameServer;
		//remote delegates must be wrapped 
		private CallbackWrapper callbackWrapper;
		

		public ClientDelegate(JoinEvent joinEvent,StartEvent startEvent,GameEvent gameEvent)
		{	
            try{
			    //default tcp channel mit '0
			    TcpChannel chan= new TcpChannel(0);
			    ChannelServices.RegisterChannel(chan);
			    //getting session facade
			    MarshalByRefObject obj=(MarshalByRefObject) RemotingServices.Connect(
				    typeof(IFacadeMenu),"tcp://"+address+"/dynablaster/SessionFacade");
			    if(obj==null)
    				throw new ServerException("Server object not found");
	    		menuServer= obj as IFacadeMenu;
		    	gameServer= obj as IFacadeGame;
			    callbackWrapper=new CallbackWrapper(joinEvent,startEvent,gameEvent);
            }catch(RemotingException re){
				//remoting exception an gui weiterleiten 
				throw new ServerAccessException(re.Message);
			}
		}

        public void SetGameEvent(GameEvent gameEvent){
            callbackWrapper.SetGameEvent(gameEvent);
        }


		//+++++++++++++++++++++METHODEN FOR MENU++++++++++++++++++++++++++++++++++++++
		//

		public string[] GetAvailableGames()
		{
            try{
                return this.menuServer.GetAvailableGames();
            }catch(SocketException re){
				throw new ServerAccessException(re.Message);
			}			
		}

		public void JoinGame(string game,string player)
		{
            try{
			    this.menuServer.JoinGame(game, player,new StartEvent(this.callbackWrapper.LocallyHandleStartEvent),
								new GameEvent(this.callbackWrapper.LocallyHandleGameEvent));
            }catch(SocketException re){
				throw new ServerAccessException(re.Message);
			}			
		}

		//see IBusinessDelegate
		public void NewGame(string game, string player)
		{
            try{
			    this.menuServer.NewGame(game,player,new JoinEvent(this.callbackWrapper.LocallyHandleJoinEvent),
											new StartEvent(this.callbackWrapper.LocallyHandleStartEvent),
												new GameEvent(this.callbackWrapper.LocallyHandleGameEvent));
			}catch(SocketException re){
				throw new ServerAccessException(re.Message);
			}			
		}
		
		
		// see IBusinessDelegate
		public void StartGame(string game)
		{
			try{
				this.menuServer.StartGame(game);
			}catch(SocketException re){
				throw new ServerAccessException(re.Message);
			}
		}

		//
		//++++++++++++++++++++++END METHODS FOR MENU+++++++++++++++++++


		//+++++++++++++++++++++METHODS FOR GAMEPLAY+++++++++++++++++++++++++++++
		//

		
		// see IBusinessDelegate		
		public void PlayerMoveUp(string game, string player)
		{
            try{
			    this.gameServer.PlayerMoveUp(game,player);
            }catch(SocketException re){
				throw new ServerAccessException(re.Message);
			}
		}

		
		// see IBusinessDelegate
		public void PlayerMoveRight(string game, string player)
		{
            try{
			    this.gameServer.PlayerMoveRight(game,player);
            }catch(SocketException re){
				throw new ServerAccessException(re.Message);
			}
		}

		
		// see IBusinessDelegate
		public void PlayerMoveDown(string game, string player)
		{
            try{
			    this.gameServer.PlayerMoveDown(game,player);
            }catch (SocketException re){        
                throw new ServerAccessException(re.Message);
            }
		}
		
		// see IBusinessDelegate
		public void PlayerMoveLeft(string game, string player)
		{
            try{
			    this.gameServer.PlayerMoveLeft(game,player);
            }catch(SocketException re){
				//remoting exception an gui weiterleiten 
				throw new ServerAccessException(re.Message);
			}
		}

		
		// see IBusinessDelegate
		public void PlaceBomb(string game, string player)
		{
            try{
			    this.gameServer.PlaceBomb(game,player);
            }catch (SocketException re){
                throw new ServerAccessException(re.Message);
            }
		}

        // see IBusinessDelegate
		public void ClientSendFinishedGame(string game)
		{
            try{
		    	this.gameServer.ClientSendsFinishedGame(game);
            }catch (SocketException re){
                throw new ServerAccessException(re.Message);
            }
		}
		//
		//+++++++++++++++++++++END METHODS FOR GAMEPLAY++++++++++++++++++++++++
		
	}
}
