using System;
using System.Collections;
using System.Text;

using dynablaster.client.logger;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;



namespace dynablaster.client.gui.gameplay
{
    public class UpdateGameField
    {

        private IDrawer drawer;
        private ILogger logger;


        //creating update field for GameGUI
        public static UpdateGameField CreateGUIDrawerUpdateField(DynablasterGUI gameGUI){
            return new UpdateGameField(new DrawerGUIItems(gameGUI.CreateGraphics()), (ILogger)gameGUI);
        }

        //game field is all fields, players and bombs     
        public UpdateGameField(IDrawer drawer,ILogger logger){
            this.drawer = drawer;
            this.logger = logger;
        }

        public void Update(GameState gameState){
            this.UpdateFields(gameState.cachedMap);
            this.UpdatePlayers(gameState.cachedPlayers);
            this.UpdateBombs(gameState.cachedBombs);
        }

        private void UpdateFields(Field[,] map)
        {
            for (int i = 0; i < map.GetLength(0); i++)
                for (int j = 0; j < map.GetLength(1); j++)
                    drawer.DrawGameObject(map[i, j], i, j);
        }

        private void UpdatePlayers(IList players)
        {
            if (players == null)
                return;
            foreach (Player player in players)
                drawer.DrawGameItem(player, player.getXCoord(), player.getYCoord());
        }

        private void UpdateBombs(IList bombs)
        {
            //no bombs there
            if (bombs == null)                
                return;
            //alle bomben in der liste 
            foreach (Bomb b in bombs){                
                //sollen gezeichnet werden
                drawer.DrawGameItem(b, b.GetXCoord(), b.GetYCoord());
            }
        }

    }
}
