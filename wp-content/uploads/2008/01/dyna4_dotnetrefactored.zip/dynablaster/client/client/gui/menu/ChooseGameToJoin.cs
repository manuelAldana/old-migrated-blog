using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.utils;

using dynablaster.client.exceptions;

namespace dynablaster.client.gui.menu
{
    public class ChooseGameToJoin : MenuWindow
    {


        private System.Windows.Forms.Label labelGamesAvailable;
        private System.Windows.Forms.Button buttonJoinGame;
        private System.Windows.Forms.ComboBox gameList;
        private System.Windows.Forms.Button buttonReloadAvailableGames;


        public ChooseGameToJoin(DynablasterGUI parentWindow)
            : base(parentWindow)
        {
            try
            {
                InitControls();
                AddControlsToParentWindow();
                parentWindow.initBusinessDelegate();
                parentWindow.SetAdviceForUserLabelText("Please choose a game!");
                labelGamesAvailable.Text = "Games:";
                //default, no game is selected -> no option to start game
                buttonJoinGame.Enabled = false;
                UpdateAvailableGamesList();
            }catch (DynablasterException de){
                Log(de.Message);
            }catch(ServerAccessException sae){
                parentWindow.SetAdviceForUserLabelText("Server problems, check, if firewall blocks, network is down or you forgot to start the server!!");
                RemoveControls();
                return;
            }

        }

        private void AddControlsToParentWindow()
        {
            parentWindow.Controls.Add(this.labelGamesAvailable);
            parentWindow.Controls.Add(this.buttonJoinGame);
            parentWindow.Controls.Add(this.gameList);
            parentWindow.Controls.Add(this.buttonReloadAvailableGames);
        }


        private void InitControls()
        {
            this.labelGamesAvailable = new System.Windows.Forms.Label();
            this.buttonJoinGame = new System.Windows.Forms.Button();
            this.gameList = new System.Windows.Forms.ComboBox();
            this.buttonReloadAvailableGames = new System.Windows.Forms.Button();

            this.labelGamesAvailable.Location = new System.Drawing.Point(56, 144);
            this.labelGamesAvailable.Name = "label3";
            this.labelGamesAvailable.Size = new System.Drawing.Size(160, 16);
            this.labelGamesAvailable.TabIndex = 10;
            this.labelGamesAvailable.Text = "Games available to join:";
            this.gameList.Location = new System.Drawing.Point(56, 168);
            this.gameList.Name = "spielauswahl";
            this.gameList.Size = new System.Drawing.Size(160, 21);
            this.gameList.TabIndex = 9;
            this.gameList.Text = "\'please choose\'";
            this.gameList.SelectedIndexChanged += new System.EventHandler(this.gameList_SelectedIndexChanged);
            this.buttonJoinGame.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonJoinGame.Location = new System.Drawing.Point(240, 136);
            this.buttonJoinGame.Name = "spielTeilnahme";
            this.buttonJoinGame.Size = new System.Drawing.Size(160, 104);
            this.buttonJoinGame.TabIndex = 3;
            this.buttonJoinGame.Text = "Accept chosen game";
            this.buttonJoinGame.UseVisualStyleBackColor = false;
            this.buttonJoinGame.Click += new System.EventHandler(this.JoinGame_Click);
            this.buttonReloadAvailableGames.BackColor = System.Drawing.Color.LightYellow;
            this.buttonReloadAvailableGames.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReloadAvailableGames.Location = new System.Drawing.Point(56, 200);
            this.buttonReloadAvailableGames.Name = "auswahlAktButton";
            this.buttonReloadAvailableGames.Size = new System.Drawing.Size(160, 24);
            this.buttonReloadAvailableGames.TabIndex = 10;
            this.buttonReloadAvailableGames.Text = "Refresh game list";
            this.buttonReloadAvailableGames.UseVisualStyleBackColor = false;
            this.buttonReloadAvailableGames.Click += new System.EventHandler(this.ReloadAvailableGamesButton_Click);
        }

        private void ReloadAvailableGamesButton_Click(object sender, System.EventArgs e)
        {
            try{
                this.UpdateAvailableGamesList();
            }catch(ServerAccessException sae){
                parentWindow.SetAdviceForUserLabelText("Server problems, check, if firewall blocks, network is down or you forgot to start the server!!");
                RemoveControls();
                return;
            }
        }

        private void gameList_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            //now because a game was chosen, the game can be started (through accordant button)
            this.buttonJoinGame.Enabled = true;
        }

        private void UpdateAvailableGamesList()
        {
            string[] availableGames = parentWindow.businessDelegate.GetAvailableGames();
            this.gameList.BeginUpdate();            
            //reset combo box, so names don't appear multiple times
            this.gameList.Items.Clear();
            for (int i = 0; i < availableGames.Length; i++)
                this.gameList.Items.Add(availableGames[i]);
            this.gameList.EndUpdate();
        }

        private void JoinGame_Click(object sender, System.EventArgs e)
        {
            try
            {
                parentWindow.gameName = this.gameList.SelectedItem.ToString();
                Log("es wurde ausgew�hlt: " + parentWindow.gameName);
                parentWindow.businessDelegate.JoinGame(parentWindow.gameName, parentWindow.playerName);
                //new window
                RemoveControls();
                parentWindow.windowState = new WaitForStart(parentWindow);
            }
            //catch, if game is full
            catch (DynablasterException de)
            {
                Log(de.Message);
            }
        }

        private void RemoveControls()
        {
            parentWindow.Controls.Remove(this.buttonReloadAvailableGames);
            parentWindow.Controls.Remove(this.labelGamesAvailable);
            parentWindow.Controls.Remove(this.gameList);
            parentWindow.Controls.Remove(this.buttonJoinGame);
        }
    }
    
}
