using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace dynablaster.client.gui
{

    public delegate void setTextCallback(String s);
    
    /// <summary>
    /// Zusammenfassung f�r EinleitenDialog.
    /// </summary>
    public class EnterTextDialog : System.Windows.Forms.Form
    {
        public const string LABEL_TEXT_ENTER_GAME_NAME = "Please enter a name for the new game:";
        public const string LABEL_TEXT_ENTER_PLAYER_NAME = "Please enter a player name:";

        
        private System.Windows.Forms.Label labelEntryGameName;
        private System.Windows.Forms.TextBox gameName;
        private System.Windows.Forms.Button buttonOK;
        private event setTextCallback setTextCallback;
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        
        public EnterTextDialog(setTextCallback setTextCallback,string labelText)
        {
            //
            // Erforderlich f�r die Windows Form-Designerunterst�tzung
            //
            InitializeComponent();
            this.setTextCallback += setTextCallback;
            labelEntryGameName.Text = labelText;
            this.ShowDialog();
        }


        /// <summary>
        /// Die verwendeten Ressourcen bereinigen.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        public string GetName()
        {
            return gameName.Text;
        }

        #region Vom Windows Form-Designer generierter Code
        /// <summary>
        /// Erforderliche Methode f�r die Designerunterst�tzung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelEntryGameName = new System.Windows.Forms.Label();
            this.gameName = new System.Windows.Forms.TextBox();
            this.buttonOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.labelEntryGameName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.labelEntryGameName.Location = new System.Drawing.Point(32, 32);
            this.labelEntryGameName.Name = "label1";
            this.labelEntryGameName.Size = new System.Drawing.Size(256, 23);
            this.labelEntryGameName.TabIndex = 0;
            this.labelEntryGameName.TextAlign = ContentAlignment.TopCenter;
            // 
            // textBox1
            // 
            this.gameName.Location = new System.Drawing.Point(64, 56);
            this.gameName.Name = "textBox1";
            this.gameName.Size = new System.Drawing.Size(192, 20);
            this.gameName.TabIndex = 1;
            this.gameName.Text = "";
            // 
            // button1
            // 
            this.buttonOK.Location = new System.Drawing.Point(128, 88);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(40, 32);
            this.buttonOK.TabIndex = 2;
            this.buttonOK.Text = "OK";
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);

            // 
            // EinleitenDialog
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(304, 142);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.gameName);
            this.Controls.Add(this.labelEntryGameName);
            this.Name = "EinleitenDialog";
            this.Text = "Einleiten Dialog";
            this.ResumeLayout(false);
            this.StartPosition = FormStartPosition.CenterScreen;

        }
        #endregion

        
        private void buttonOK_Click(object sender, System.EventArgs e)
        {
            if (IsEmpty(gameName.Text))
                MessageBox.Show("The name must not be empty!");
            else
            {
                setTextCallback(gameName.Text);
                this.Close();
            }
        }


        private bool IsEmpty(String str)
        {
            if (str.Trim().Equals(""))
                return true;
            return false;
        }


    }
}
