using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;
using dynablaster.server.game;
using dynablaster.tests.utils;

using dynablaster.shared_libs.exceptions;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.server
{
    

    [TestFixture]
    public class PlayerMoves
    {
        IPlayerMoveHandler playerMoveHandler;

        //args passed to handler
        DynaEventArgs receivedArgs;
        bool callbackCalled;

        public void GameEventHandler(DynaEventArgs args){
            this.callbackCalled = true;
            this.receivedArgs = args;
        }       
        
        [SetUp]
        public void SetUp(){
            this.callbackCalled = false;
            this.playerMoveHandler = new PlayerMoveHandler(GameEventHandler);            
        }
        

        [Test]
        public void PlayerCannotMove(){
            GameState gameStateNoObstaclesOnePlayer = Factory.CreateGameStateObstaclesOnePlayer();
            try{
                playerMoveHandler.PlayerMoveLeft("searchedPlayer",gameStateNoObstaclesOnePlayer);
                Assert.Fail();
            }catch(DynablasterException de){
                Assert.IsFalse(this.callbackCalled);
            }            
            try{
                playerMoveHandler.PlayerMoveRight("searchedPlayer",gameStateNoObstaclesOnePlayer);
                Assert.Fail();
            }catch(DynablasterException de){}            
            try{
                playerMoveHandler.PlayerMoveUp("searchedPlayer",gameStateNoObstaclesOnePlayer);
                Assert.Fail();
            }catch (DynablasterException de) { }            
            try{
                playerMoveHandler.PlayerMoveDown("searchedPlayer",gameStateNoObstaclesOnePlayer);
                Assert.Fail();
            }catch (DynablasterException de) { }            
        }

        

        [Test]
        public void PlayerCanMoveRight(){            
            try{
                playerMoveHandler.PlayerMoveRight("searchedPlayer", Factory.CreateGameStateNoObstaclesOnePlayer());            
            }catch(DynablasterException de){
                Assert.Fail();
            }
        }

        [Test]
        public void PlayerCanMoveLeft(){
            try{
                playerMoveHandler.PlayerMoveLeft("searchedPlayer", Factory.CreateGameStateNoObstaclesOnePlayer());            
            }catch(DynablasterException de){
                Assert.Fail();
            }
        }

        [Test]
        public void PlayerCanMoveUp(){
            try{
                playerMoveHandler.PlayerMoveUp("searchedPlayer", Factory.CreateGameStateNoObstaclesOnePlayer());
            }catch(DynablasterException de){
                Assert.Fail();
            }
        }
  
        [Test]
        public void PlayerCanMoveDown(){
            try{
                playerMoveHandler.PlayerMoveDown("searchedPlayer", Factory.CreateGameStateNoObstaclesOnePlayer());
            }catch(DynablasterException de){
                Assert.Fail();
            }
        }

        [Test]
        public void PlayerMovesRight(){
            GameState gameStateNoObstaclesOnePlayer = Factory.CreateGameStateNoObstaclesOnePlayer();
            playerMoveHandler.PlayerMoveRight("searchedPlayer", gameStateNoObstaclesOnePlayer);
            Assert.AreEqual(2, gameStateNoObstaclesOnePlayer.getPlayerByName("searchedPlayer").getXCoord());
            Assert.AreEqual(1, gameStateNoObstaclesOnePlayer.getPlayerByName("searchedPlayer").getYCoord());
            Assert.IsTrue(this.receivedArgs is PlayerMovedArgs);
        }            

        [Test]
        public void PlayerFindsTreasure(){
            GameState gameStateNoObstaclesOnePlayer = Factory.CreateGameStateNoObstaclesOnePlayer();
            gameStateNoObstaclesOnePlayer.cachedMap[2, 1] = new Treasure(2, 1);
            this.playerMoveHandler.PlayerMoveRight("searchedPlayer", gameStateNoObstaclesOnePlayer);
            Assert.IsTrue(this.receivedArgs is WinnerEventArgs);
        }
  }
    
}
