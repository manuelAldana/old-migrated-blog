using System;
using System.Collections;
using System.Text;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;
using dynablaster.server.game;
using dynablaster.tests.utils;

using dynablaster.shared_libs.exceptions;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.server
{
    [TestFixture]
    public class DestroyStones
    {

        DestroyStonesHandler destroyStoneHandler;
        GameState gameState;

        bool mapChangedCallbackGotCalled;

        public void mapChangedCallback(DynaEventArgs args){
            Console.WriteLine("gotcalled");
            this.mapChangedCallbackGotCalled = true;
        }

        public DestroyStones(){
            this.destroyStoneHandler = new DestroyStonesHandler(mapChangedCallback);
            this.gameState = new GameState();                        
            //callback initially not called
            this.mapChangedCallbackGotCalled= false;
        }

        [Test]
        public void DestroyLeftStone(){
            gameState.cachedMap = Factory.CreateGameMapLeftStone();
            destroyStoneHandler.DestroyStonesInBombRange(1, 1, 2, gameState);
            Assert.IsTrue(MapItemIsNoStone(gameState.cachedMap, 0, 1));
            Assert.IsTrue(this.mapChangedCallbackGotCalled);
        }
        [Test]
        public void DestroyRightStone()
        {
            gameState.cachedMap = Factory.CreateGameMapRightStone();
            destroyStoneHandler.DestroyStonesInBombRange(1, 1, 2, gameState);
            Assert.IsTrue(MapItemIsNoStone(gameState.cachedMap, 2, 1));
            Assert.IsTrue(this.mapChangedCallbackGotCalled);
        }
        [Test]
        public void DestroyUpperStone()
        {
            gameState.cachedMap = Factory.CreateGameMapUpperStone();
            destroyStoneHandler.DestroyStonesInBombRange(1, 1, 2, gameState);
            Assert.IsTrue(MapItemIsNoStone(gameState.cachedMap, 1,0));
            Assert.IsTrue(this.mapChangedCallbackGotCalled);
        }
        [Test]
        public void DestroyLowerStone()
        {
            gameState.cachedMap = Factory.CreateGameMapLowerStone();
            destroyStoneHandler.DestroyStonesInBombRange(1, 1, 2, gameState);
            Assert.IsTrue(MapItemIsNoStone(gameState.cachedMap, 1, 2));
            Assert.IsTrue(this.mapChangedCallbackGotCalled);
        }
       

        private bool MapItemIsNoStone(Field[,] map,int x,int y){            
            if(map[x,y] is Stone)
                return false;
            return true;
        }

    }
}
