using System;
using System.Collections;
using System.Text;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;
using dynablaster.server.game;
using dynablaster.tests.utils;

using dynablaster.shared_libs.exceptions;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.server
{

    [TestFixture]
    public class KillPlayer
    {
        KillPlayerHandler killPlayerHandler;
        Field[,] map;
        IList players;

        public void doNothing(DynaEventArgs args){
        }

        [SetUp]
        public void SetUp()
        {
            this.killPlayerHandler = new KillPlayerHandler(doNothing);
            this.map = Factory.CreateGameMapNoObstacles();
            this.players = new ArrayList();
        }

        [Test]
        public void KillPlayerStandingInBombEpicenter(){
            players.Add(new Player(Flags.ANY_INT, "toBeKilled", 1, 1));
            GameState gameState = new GameState(this.map, this.players);
            gameState=this.killPlayerHandler.KillPlayersHitByBomb(1, 1, 1,gameState);
            Assert.IsTrue(PlayerKilled(gameState, "toBeKilled"));
        }
        [Test]
        public void KillMultiplePlayers(){
            this.players.Add(new Player(Flags.ANY_INT, "toBeKilled", 1, 1));
            this.players.Add(new Player(Flags.ANY_INT, "toBeKilledToo", 1, 1));
            GameState gameState = new GameState(this.map, this.players);
            gameState=this.killPlayerHandler.KillPlayersHitByBomb(1, 1, 1, gameState);
            Assert.IsTrue(PlayerKilled(gameState, "toBeKilled"));
            Assert.IsTrue(PlayerKilled(gameState, "toBeKilledToo"));
        }

        [Test]
        public void KillPlayerInRange(){
            this.players.Add(new Player(Flags.ANY_INT, "toBeKilled", 1, 2));
            GameState gameState = new GameState(this.map, this.players);
            gameState = this.killPlayerHandler.KillPlayersHitByBomb(1, 1, 1, gameState);
            Assert.IsTrue(PlayerKilled(gameState, "toBeKilled"));
        }

        [Test]
        public void KillMultiplePlayersInRange()
        {
            this.players.Add(new Player(Flags.ANY_INT, "toBeKilled", 1, 0));
            this.players.Add(new Player(Flags.ANY_INT, "toBeKilledToo", 0, 1));
            GameState gameState = new GameState(this.map, this.players);
            gameState = this.killPlayerHandler.KillPlayersHitByBomb(1, 1, 1, gameState);
            Assert.IsTrue(PlayerKilled(gameState, "toBeKilled"));
            Assert.IsTrue(PlayerKilled(gameState, "toBeKilledToo"));
        }

        private bool PlayerKilled(GameState gameState, string playerName){
            if (gameState.getPlayerByName(playerName) == null)
                return true;
            return false;
        }


    }
}
