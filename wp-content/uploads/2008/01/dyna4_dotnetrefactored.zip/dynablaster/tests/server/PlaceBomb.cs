using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;
using dynablaster.server.game;
using dynablaster.tests.utils;

using dynablaster.shared_libs.exceptions;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.server
{
    
    [TestFixture]
    public class PlaceBomb
    {
        bool gameEventCalled=false;
        DynaEventArgs callbackArgs;
        
        void gameEventdoNothing(DynaEventArgs args){
            this.gameEventCalled = true;
            this.callbackArgs = args;
        }
        void explodeEventDoNothing(object sender,int x, int y){
        
        }
                

        [Test]
        public void PlayerPlacesBombOnTopOfExistingOne(){
            GameState gameState = Factory.CreateGameStateNoObstaclesOnePlayer();
            //place bomb, where player stands
            gameState.AddBomb(new Bomb(1,1));
            PlaceBombHandler placeBomb = new PlaceBombHandler(gameEventdoNothing,explodeEventDoNothing);
            try{
                //place bomb at the field where player stands and one bomb already exists
                placeBomb.PlaceBomb("searchedPlayer", gameState, Factory.CreateEmptyArrayList());
                Assert.Fail();
            }catch(DynablasterException de){}
        }

        [Test]
        public void PlayerPlacesBomb(){
            GameState gameState = Factory.CreateGameStateNoObstaclesOnePlayer();
            PlaceBombHandler placeBomb = new PlaceBombHandler(gameEventdoNothing, explodeEventDoNothing);
            //initially empty
            IList bombExplodingList=Factory.CreateEmptyArrayList();
            placeBomb.PlaceBomb("searchedPlayer", gameState, bombExplodingList);
            Assert.IsTrue(BombExistsWherePlayerStands(gameState.cachedBombs,gameState.getPlayerByName("searchedPlayer")));
            Assert.IsTrue(gameEventCalled);
            Assert.IsTrue(this.callbackArgs is BombEventArgs);
            Assert.IsTrue(PlacedBombExistsInCallbackArgs(1, 1, this.callbackArgs));
            //bombExploding list not empty anymore
            Assert.IsTrue(bombExplodingList.Count==1);            
        }

        private bool PlacedBombExistsInCallbackArgs(int x, int y,DynaEventArgs args){
            IList placedBombs = ((BombEventArgs)args).getGameState().cachedBombs;
            foreach(Bomb bomb in placedBombs)
                if (bomb.GetXCoord() == x && bomb.GetYCoord() == y)
                    return true;
            return false;
        }

        private bool BombExistsWherePlayerStands(IList bombs,Player player){
            foreach(Bomb bomb in bombs)
                if (bomb.GetXCoord() == player.getXCoord())
                    if (bomb.GetYCoord() == player.getYCoord())
                        return true;
            return false;
        }
            
    }
}
