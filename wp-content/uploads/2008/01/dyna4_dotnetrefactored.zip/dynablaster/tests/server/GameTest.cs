using System;
using System.Collections;
using System.Text;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.exceptions;
using dynablaster.shared_libs.callbacks;

using dynablaster.server.game;
using dynablaster.tests.utils;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.server
{
    [TestFixture]
    public class GameTest
    {
        private static int MAX_PLAYERS = 4;


        public void JoinCallback(JoinEventArgs args){
        }

        MockRepository mocks;
        //REMOVE
        JoinEvent anyJoinEventCallback;
        StartEvent anyStartEventCallback;
        GameEvent anyGameEventCallback;
        MenuStage menuStage;
        

        public GameTest(){
            this.mocks = new MockRepository();
            
            this.anyJoinEventCallback = mocks.CreateMock<JoinEvent>();
            this.anyStartEventCallback = mocks.CreateMock<StartEvent>();
            this.anyGameEventCallback = mocks.CreateMock<GameEvent>();
        }

        [SetUp]
        public void SetUp(){            
            this.menuStage = new MenuStage(MAX_PLAYERS);
        }

        [Test]
        //first player is always first player to be added
        public void PlayerRegistersGame(){            
            RegisterGame("player1","anyGame");            
            //first player registered
            Assert.IsTrue(menuStage.players.Count==1,"There must be one player in game");
            Assert.IsTrue(ContainsPlayer(menuStage.players,"player1"),"1st player was not added");
            Player registeredPlayer=GetPlayerByName(menuStage.players,"player1");
            //player is on top left
            Assert.IsTrue(CoordinatesMatch(registeredPlayer, 0, 0),"position must be top left");            
        }

        private void RegisterGame(string playerName,string gameName){
            Field[,] map = Factory.CreateGameMapNoObstacles();
            this.menuStage.RegisterGame(playerName, map,anyJoinEventCallback);
        }

        private bool CoordinatesMatch(Player player, int xCoord,int yCoord){
            if (player.getXCoord() == xCoord && player.getYCoord() == yCoord)
                return true;
            return false;
        }

        private bool ContainsPlayer(IList players,string playerName){
            if (GetPlayerByName(players, playerName) != null)
                return true;
            return false;
        }

        private Player GetPlayerByName(IList players,string playerName){
            foreach (Player player in players)
                if (player.GetName().Equals(playerName))
                    return player;
            return null;
        }

        [Test]
        public void SecondPlayerJoins(){
            RegisterGame("player1",Flags.ANY_STRING);
            menuStage.AddPlayer("player2");
            Assert.IsTrue(menuStage.players.Count==2,"There must be 2 players");
            Assert.IsTrue(ContainsPlayer(menuStage.players,"player2"),"2nd player was not added");
            Player secondPlayer=GetPlayerByName(menuStage.players,"player2");
            int xBoundGameField = GetXBoundGameField(menuStage);
            Assert.IsTrue(CoordinatesMatch(secondPlayer,xBoundGameField,0),"position must be top right");
        }

        [Test]
        public void ThirdPlayerJoins(){
            RegisterGame("player1",Flags.ANY_STRING);
            menuStage.AddPlayer("player2");
            menuStage.AddPlayer("player3");
            Assert.IsTrue(menuStage.players.Count == 3,"There must be 3 players");
            Assert.IsTrue(ContainsPlayer(menuStage.players, "player3"),"3rd was not added");
            Player secondPlayer = GetPlayerByName(menuStage.players, "player3");
            int yBoundGameField = GetYBoundGameField(menuStage);
            //position of player is on down left corner
            Assert.IsTrue(CoordinatesMatch(secondPlayer, 0, yBoundGameField),"position must be bottom left");
        }


        [Test]
        public void ForthPlayerJoins(){
            RegisterGame("player1",Flags.ANY_STRING);
            menuStage.AddPlayer("player2");
            menuStage.AddPlayer("player3");
            menuStage.AddPlayer("player4");
            Assert.IsTrue(menuStage.players.Count == 4,"There must be 4 players");
            Assert.IsTrue(ContainsPlayer(menuStage.players, "player4"),"4th player was not added");
            Player secondPlayer = GetPlayerByName(menuStage.players, "player4");
            int xBoundGameField = GetXBoundGameField(menuStage);
            int yBoundGameField = GetYBoundGameField(menuStage);            
            Assert.IsTrue(CoordinatesMatch(secondPlayer, xBoundGameField, yBoundGameField),"position must be bottom right");            
        }

        [Test]
        public void AddTooManyPlayers(){
            try{
                RegisterGame("player1", Flags.ANY_STRING);
                menuStage.AddPlayer("player2");
                menuStage.AddPlayer("player3");
                menuStage.AddPlayer("player4");
                menuStage.AddPlayer("OnePlayerTooMuch");
                Assert.Fail("Exception should be thrown when one player too much was added");
            }catch(DynablasterException de){}

        }

        private int GetXBoundGameField(MenuStage game){
            //-1: array starts with 0
            return game.gameMap.GetLength(0)-1;
        }

        private int GetYBoundGameField(MenuStage game){
            //-1: array starts with 0
            return game.gameMap.GetLength(1)-1;
        }

    }
}
