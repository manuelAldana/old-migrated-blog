using System;
using System.Collections;
using System.Text;


using dynablaster.shared_libs.game;
using dynablaster.shared_libs.game.gameObjects;

namespace dynablaster.tests.utils
{
    public class GameObjectObstacle : Field
    {
        public GameObjectObstacle() : base(Flags.ANY_INT, Flags.ANY_INT) { }
        public override bool IsObstacle() { return true; }
    }

    public class GameObjectNoObstacle : Field
    {
        public GameObjectNoObstacle() : base(Flags.ANY_INT, Flags.ANY_INT) { }
        public override bool IsObstacle() { return false; }
    }

    public class Factory
    {

        public static IList CreateEmptyArrayList(){
            return new ArrayList();
        }

        public static Field[,] CreateGameMap(Field type)
        {
            Field[,] map = new Field[3, 3];
            //ordered top,left,right,bottom direction
            map[0, 1] = type;
            map[1, 0] = type;
            map[1, 2] = type;
            map[2, 1] = type;
            return map;
        }

        public static Field[,] CreateGameMapNoObstacles()
        {
            return CreateGameMap(new GameObjectNoObstacle());
        }

        public static Field[,] CreateGameMapObstacles()
        {
            return CreateGameMap(new GameObjectObstacle());
        }

        public static GameState CreateGameStateObstaclesOnePlayer()
        {
            IList players = new ArrayList();
            Player playerInTheCenter = new Player(Flags.ANY_INT, "searchedPlayer", 1, 1);
            players.Add(playerInTheCenter);
            GameState gameStateNoObstaclesOnePlayer = new GameState(CreateGameMapObstacles(), players);
            return gameStateNoObstaclesOnePlayer;
        }

        
        public static GameState CreateGameStateNoObstaclesOnePlayer()
        {
            IList players = new ArrayList();
            Player playerInTheCenter = new Player(Flags.ANY_INT, "searchedPlayer", 1, 1);
            players.Add(playerInTheCenter);
            return new GameState(CreateGameMapNoObstacles(), players);
        }

        public static Field[,] CreateGameMapLeftStone()
        {
            Field[,] map = CreateGameMapNoObstacles();
            //change left to obstacle
            map[0, 1] = new Stone(0,1);
            return map;            
        }

        public static Field[,] CreateGameMapRightStone()
        {
            Field[,] map = CreateGameMapNoObstacles();
            //change right to obstacle
            map[2, 1] = new Stone(2,1);
            return map;
        }

        public static Field[,] CreateGameMapUpperStone()
        {
            Field[,] map = CreateGameMapNoObstacles();
            //change upper to obstacle
            map[1, 0] = new Stone(1,0);
            return map;
        }

        public static Field[,] CreateGameMapLowerStone(){
            Field[,] map = CreateGameMapNoObstacles();
            //change lower to obstacle
            map[1, 2] = new Stone(1,2);
            return map;
        }


    }
}
