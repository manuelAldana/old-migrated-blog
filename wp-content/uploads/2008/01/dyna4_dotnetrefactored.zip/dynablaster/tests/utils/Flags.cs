using System;
using System.Collections.Generic;
using System.Text;

namespace dynablaster.tests.utils
{
    public class Flags
    {
        public const int ANY_INT=0;
        public const string ANY_STRING = "any";        

    }
}
