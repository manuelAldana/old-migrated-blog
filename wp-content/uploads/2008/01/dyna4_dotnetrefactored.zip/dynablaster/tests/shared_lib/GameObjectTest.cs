using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.tests.utils;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.shared_lib
{
    [TestFixture]
    public class GameObjectTest
    {
        [Test]
        public void ObjectIsObstacle(){
            Assert.IsTrue(new Stone(Flags.ANY_INT,Flags.ANY_INT).IsObstacle());
            Assert.IsTrue(new Wall(Flags.ANY_INT, Flags.ANY_INT).IsObstacle());            
        }

        [Test]
        public void ObjectIsNoObstacle(){
            Assert.IsFalse(new Way(Flags.ANY_INT, Flags.ANY_INT).IsObstacle());
            Assert.IsFalse(new Treasure(Flags.ANY_INT, Flags.ANY_INT).IsObstacle());
        }


        [Test]
        public void AddAndRemoveBombAt(){
            GameState gameState = new GameState(Factory.CreateGameMapNoObstacles(), null);
            gameState.AddBomb(new Bomb(1, 1));
            Assert.IsTrue(gameState.cachedBombs.Count == 1);
            gameState.RemoveBombAt(1, 1);
            Assert.IsTrue(gameState.cachedBombs.Count == 0);
        }
    }
}
