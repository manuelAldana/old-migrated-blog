using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Windows.Forms;

using dynablaster.client.gui;
using dynablaster.client.gui.gameplay;

using dynablaster.client.logger;
using dynablaster.client.delegates;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;
using dynablaster.tests.utils;

using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.client.gui
{
    
    [TestFixture]
    public class KeyEventHandlerTest
    {

        ILogger logger;
        MockRepository mocks;
        IBusinessDelegate businessDelegate;
        
        [SetUp]
        public void SetUp(){
            this.logger = new DummyLogger();
            this.mocks = new MockRepository();
            this.businessDelegate=this.mocks.CreateMock<IBusinessDelegate>();            

        }

        [TearDown]
        public void TearDown()
        {
            mocks.BackToRecord(this.businessDelegate);
        }

        //player who has no walls in front -> can potentially move to all directions
        private Player CreatePlayerNotAtFieldBorder(){
            return new Player(Flags.ANY_INT, Flags.ANY_STRING, 1, 1);
        }

        private KeyboardHandler CreateKeyboardHandlerNoBorderInFrontPlayer(){
            return new KeyboardHandler(this.logger, this.businessDelegate, Flags.ANY_STRING, CreatePlayerNotAtFieldBorder(), 3, 3); 
        }

        [Test]
        public void LeftKeyPressedNoWall(){
            this.businessDelegate.PlayerMoveLeft(Flags.ANY_STRING,Flags.ANY_STRING);
            LastCall.IgnoreArguments();
            mocks.ReplayAll();
            CreateKeyboardHandlerNoBorderInFrontPlayer().HandleKeyEvent(new KeyEventArgs(Keys.Left));
        }
        [Test]
        public void RightKeyPressedNoWall()
        {
            this.businessDelegate.PlayerMoveRight(Flags.ANY_STRING, Flags.ANY_STRING);
            LastCall.IgnoreArguments();
            mocks.ReplayAll();
            CreateKeyboardHandlerNoBorderInFrontPlayer().HandleKeyEvent(new KeyEventArgs(Keys.Right));
        }
        [Test]
        public void UpKeyPressedNoWall()
        {
            this.businessDelegate.PlayerMoveUp(Flags.ANY_STRING, Flags.ANY_STRING);
            LastCall.IgnoreArguments();
            mocks.ReplayAll();
            CreateKeyboardHandlerNoBorderInFrontPlayer().HandleKeyEvent(new KeyEventArgs(Keys.Up));
        }
        [Test]
        public void DownKeyPressedNoWall()
        {
            this.businessDelegate.PlayerMoveDown(Flags.ANY_STRING, Flags.ANY_STRING);
            LastCall.IgnoreArguments();
            mocks.ReplayAll();
            CreateKeyboardHandlerNoBorderInFrontPlayer().HandleKeyEvent(new KeyEventArgs(Keys.Down));
        }

        [Test]
        public void KeyPressedAndBorderInFront(){
            Player playerAllSidesBorder= new Player(Flags.ANY_INT, Flags.ANY_STRING, 0, 0);
            //x=0,y=0 bounds -> world has only one field -> player standing on (0,0) cannot move
            KeyboardHandler handler = new KeyboardHandler(this.logger, this.businessDelegate, Flags.ANY_STRING, playerAllSidesBorder, 0,0);
            //no expectations on business delegate, because player cannot move in any direction
            mocks.ReplayAll();
            handler.HandleKeyEvent(new KeyEventArgs(Keys.Left));
            handler.HandleKeyEvent(new KeyEventArgs(Keys.Right));
            handler.HandleKeyEvent(new KeyEventArgs(Keys.Up));
            handler.HandleKeyEvent(new KeyEventArgs(Keys.Down));            
        }

        [Test] 
        public void KeyPressedEnter(){
            Player player = new Player(Flags.ANY_INT, Flags.ANY_STRING, 0,0);
            KeyboardHandler handler = new KeyboardHandler(this.logger, this.businessDelegate, Flags.ANY_STRING,  player, 0, 0);
            this.businessDelegate.PlaceBomb(Flags.ANY_STRING, Flags.ANY_STRING);
            mocks.ReplayAll();
            handler.HandleKeyEvent(new KeyEventArgs(Keys.Enter));
        }


    }
}