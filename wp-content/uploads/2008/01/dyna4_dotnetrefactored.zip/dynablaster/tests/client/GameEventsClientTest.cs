using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

using dynablaster.client.gui;
using dynablaster.tests.utils;
using dynablaster.tests.client.utils;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;
using dynablaster.shared_libs.callbacks;



using NUnit.Framework;

namespace dynablaster.tests.client
{
    [TestFixture]
    public class GameEventsClientTest 
    {

        
        //stub out updatingGameField 
        public void doNothing(GameState gameState){
        }

        [Test]
        public void getPlayerByName(){
            GameState gameState = new GameState();
            IList players = new ArrayList();
            Player playerToBeSearched=new Player(1,"no1",0,0);
            players.Add(new Player(1, "no2", 0, 0));
            players.Add(playerToBeSearched);            
            players.Add(new Player(1,"no3",0,0));
            gameState.cachedPlayers = players;
            Assert.AreEqual(playerToBeSearched,gameState.getPlayerByName("no1"));
        }
    }
}
