using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

using dynablaster.client.gui;
using dynablaster.client.gui.gameplay;

using dynablaster.client.logger;

using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;



using NUnit.Framework;
using Rhino.Mocks;

namespace dynablaster.tests.client.gui
{

   
    [TestFixture]
    public class UpdateGameTest
    {

        private MockRepository mocks;
        private IDrawer drawer;
        private DynablasterGUI gameGUI;
        private ILogger dummyLogger;

        public UpdateGameTest(){
            this.gameGUI = new DynablasterGUI("dummyObject");
            this.dummyLogger = new DummyLogger();
        }

        
        [SetUp] 
        public void SetUp(){
            
            this.mocks = new MockRepository();
            this.drawer = mocks.CreateMock<IDrawer>();
        }

        [TearDown]
        public void TearDown(){
            mocks.BackToRecord(drawer);
        }

        private Field createGameObjectByNumber(int number, int posX, int posY)
        {
            if (number == 0)
                return new Stone(posX, posY);
            if (number == 1)
                return new Treasure(posX, posY);
            if (number == 2)
                return new Wall(posX, posY);
            if (number == 3)
                return new Way(posX, posY);
            return null;
        }

        private Field createRandomGameObject(int posX, int posY)
        {
            Random random = new Random();
            int number = random.Next(0, 3);
            return createGameObjectByNumber(number, posX, posY);
        }

        private GameState createBombs(int times)
        {
            GameState gameState = new GameState();
            gameState.cachedBombs = new List<Bomb>();
            for (int i = 0; i < times; i++)
                //i,i+1 just fixed pattern to fill
                gameState.cachedBombs.Add(new Bomb(i, i + 1));
            gameState.cachedMap = new Field[0, 0];
            gameState.cachedPlayers = new ArrayList();
            return gameState;
        }

        //DIRTY: tests should not be random -> to be fixed
        private GameState buildRandomGameState(int xBound, int yBound)
        {
            GameState gameState = new GameState();
            gameState.cachedMap = new Field[xBound, yBound];
            for (int i = 0; i < gameState.cachedMap.GetLength(0); i++)
                for (int j = 0; j < gameState.cachedMap.GetLength(1); j++)
                    gameState.cachedMap[i, j] = createRandomGameObject(i, j);
            return gameState;
        }

        

        [Test]
        public void DrawBombsCalledAppropriateTimes()
        {
            UpdateGameField updateField = new UpdateGameField(drawer, dummyLogger);
            GameState gameState = createBombs(3);
            drawer.DrawGameItem(null, 0, 0);
            LastCall.IgnoreArguments();
            LastCall.Repeat.Times(3);
            mocks.ReplayAll();
            updateField.Update(gameState);            
        }

        [Test]
        public void DrawGameObjectCalledAppropriateTimes()
        {
            UpdateGameField updateField = new UpdateGameField(drawer,dummyLogger);
            GameState gameState = buildRandomGameState(3, 4);
            drawer.DrawGameObject(null,0,0);
            LastCall.IgnoreArguments();
            LastCall.Repeat.Times(12);
            mocks.ReplayAll();
            updateField.Update(gameState);            
        }
        
        [Test]
        public void DrawGameObjectCalledWithCorrectIndex2(){
            UpdateGameField updateField=new UpdateGameField(drawer,dummyLogger);
            GameState  gameState = buildRandomGameState(1, 2);
            drawer.DrawGameObject(gameState.cachedMap[0, 0], 0, 0);
            drawer.DrawGameObject(gameState.cachedMap[0, 1], 0, 1);
            mocks.ReplayAll();
            updateField.Update(gameState);            
        }

    }
}
