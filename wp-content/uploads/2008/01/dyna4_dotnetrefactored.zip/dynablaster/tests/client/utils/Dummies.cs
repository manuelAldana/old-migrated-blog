using System;
using System.Collections.Generic;
using System.Text;

using dynablaster.client.gui;
using dynablaster.client.logger;

namespace dynablaster.tests.client.utils
{


    public class GameGUIDummy : DynablasterGUI
    {
        
        public GameGUIDummy():base("dummyGUIObject"){            
        }

        public override void Log(string s){
            //do nothing
        }
    }

    public class DummyLogger:ILogger{
        public void Log(string s){
            //do nothing
        }
    }
}
