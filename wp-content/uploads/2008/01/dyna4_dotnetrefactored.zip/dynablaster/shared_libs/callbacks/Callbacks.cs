using System;

namespace dynablaster.shared_libs.callbacks
{
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//DAS HIER SIND DIE CALLBACK DELEGATES F�R MEN�-STEUERUNG
	
	
	/// <summary>
	/// Callback an client, der ein konkretes Spiel zum Laufen bringt
	/// </summary>
	public delegate void StartEvent(GameInitArgs args);
	
	/// <summary>
	/// Callback an Client und zwar an den Spielf�hrer, dass neue Spieler
	/// dem Spiel beigetreten sind
	/// </summary>
	public delegate void JoinEvent(JoinEventArgs args);
	/// <summary>
	/// test delegate, um remote delegate zu testen
	/// </summary>
	public delegate void TestEvent(string s);
	

	

	//ENDE CALLBACK DELEGATES F�R MEN�-STEUERUNG
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//DAS HIER SIND DIE CALLBACK DELEGATES F�R GAMEPLAY
	/// <summary>
	/// Callback an Client w�hrend eines laufenden Spiels 
	/// </summary>
	public delegate void GameEvent(DynaEventArgs args);
	//ENDE CALLBACK DELEGATES F�R GAMEPLAY
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	
}
