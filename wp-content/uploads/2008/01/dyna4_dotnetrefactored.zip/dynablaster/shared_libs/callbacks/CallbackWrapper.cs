using System;
using System.Runtime.Remoting.Messaging;
using dynablaster.shared_libs.server;


namespace dynablaster.shared_libs.callbacks
{
	//makes remote delegates possible
	public class CallbackWrapper : MarshalByRefObject
	{
		//menu callbacks
		public event JoinEvent JoinEventLocallyHandler;
		public event StartEvent StartEventLocallyHandler;
		
		//gameplay callbacks
		public event GameEvent GameEventLocallyHandler;

		//binds local with remote delegates 
		public CallbackWrapper(JoinEvent joinEvent, StartEvent startEvent,GameEvent gameEvent)
		{
			JoinEventLocallyHandler+=joinEvent;
			StartEventLocallyHandler+=startEvent;
			GameEventLocallyHandler+=gameEvent;
		}

        public void SetGameEvent(GameEvent gameEvent){
            GameEventLocallyHandler=gameEvent;
        }

		
		[OneWay]
		public void LocallyHandleJoinEvent(JoinEventArgs args)
		{
			JoinEventLocallyHandler(args);
		}
			
		
		[OneWay]
		public void LocallyHandleStartEvent(GameInitArgs args)
		{
			StartEventLocallyHandler(args);
		}

		[OneWay]
		public void LocallyHandleGameEvent(DynaEventArgs args)
		{
			GameEventLocallyHandler(args);
		}

	}
}
