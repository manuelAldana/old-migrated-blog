using System;
using System.Collections;
using System.Collections.Generic;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;


namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// Event f�r den Callback bei der Spielinitialisierung
	/// </summary>
	[Serializable]
	public class GameInitArgs : EventArgs
	{
		
        private GameState gameState;

        public GameState GameState{get{return gameState;}}

        public GameInitArgs(GameState gameState){
            this.gameState = gameState;
        }        
		
        public int XBound{get{return this.gameState.XBound;}}
        public int YBound{get{return this.gameState.YBound;}}

		public Field[,] GetGameObjects(){return this.gameState.cachedMap;}
		public IList GetPlayers(){return this.gameState.cachedPlayers;}
	}
}
