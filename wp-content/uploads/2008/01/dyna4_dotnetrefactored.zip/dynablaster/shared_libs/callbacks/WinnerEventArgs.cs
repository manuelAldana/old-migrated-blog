using System;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;

namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// argumentklasse f�r den fall das treasure gefunden wurde
	/// </summary>
	[Serializable]
	public class WinnerEventArgs : DynaEventArgs
	{
		/// <summary>
		/// der gewinner des spiels
		/// </summary>
		private Player winner;
	
		
        public WinnerEventArgs(Player winner,GameState gameState):base(gameState){
            this.winner = winner;
        }

		public Player GetWinner(){return this.winner;}
		
	}
}
