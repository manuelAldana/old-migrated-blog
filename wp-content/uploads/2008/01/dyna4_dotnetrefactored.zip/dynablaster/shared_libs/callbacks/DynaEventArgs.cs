using System;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;

namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// EventArg als Callback-Datenobjekt f�r Events w�hrend eines 
	/// laufenden Spiels, dabei abstrakte klasse, nur erbende klassen 
	/// implementieren konkrete eventArgs
	/// </summary>
	[Serializable]
	public abstract class DynaEventArgs : EventArgs
	{

        private GameState gameState;

        public DynaEventArgs(){
        }

        public DynaEventArgs(GameState gameState){
            this.gameState=gameState;
        }

        public GameState getGameState(){
            return this.gameState;
        }

		
	}
}
