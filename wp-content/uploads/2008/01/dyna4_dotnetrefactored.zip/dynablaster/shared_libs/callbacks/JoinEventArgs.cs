using System;

namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// EventArg f�r Update der teilnehmenden Spieler,
	/// spielf�hrer sieht diese spielernamen in 
	/// seinem startfenster
	/// </summary>
	[Serializable]
	public class JoinEventArgs : EventArgs
	{
		/// <summary>
		/// spielernamen, die teilnehmen wollen
		/// </summary>
		string[] names;

		/// <summary>
		/// Konstruktor mit den spielernamen
		/// </summary>
		/// <param name="names"></param>
		public JoinEventArgs(string[] names)
		{
			this.names=names;
		}

		public string[] GetPlayerNames()
		{
			return this.names;
		}

        public Boolean OnePlayerJoined()
        {
            if (names.Length == 1)
                return true;
            return false;
        }

        public Boolean TwoPlayersJoined()
        {
            if (names.Length== 2)
                return true;
            return false;
        }
        public Boolean ThreePlayersJoined()
        {
            if (names.Length == 3)
                return true;
            return false;
        }
        public Boolean FourPlayersJoined()
        {
            if (names.Length == 4)
                return true;
            return false;
        }

        

	}
}
