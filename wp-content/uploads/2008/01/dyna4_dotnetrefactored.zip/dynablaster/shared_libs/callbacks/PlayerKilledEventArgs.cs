using System;

using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;

namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// klasse, die argumente des falls, dass spieler durch 
	/// bombe get�tet wird verwaltet
	/// </summary>
	[Serializable]
	public class PlayerKilledEventArgs : DynaEventArgs
	{
		/// <summary>
		/// gestorbener Spieler
		/// </summary>
		private Player killedPlayer;	

		
        public PlayerKilledEventArgs(GameState gameState,Player killedPlayer):base(gameState){
            this.killedPlayer = killedPlayer;
        }

		public Player GetKilledPlayer(){return this.killedPlayer;}
	}
}
