using System;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;


namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// EventArgs f�r den fall, dass spielfeld sich ge�ndert hat
	/// z.b. steine zerst�rt wurde
	/// </summary>
	[Serializable]
	public class MapChangedEventArgs : DynaEventArgs
	{

		
        public MapChangedEventArgs(GameState gameState):base(gameState){
        }

		
	}
}
