using System;
using System.Collections;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;

namespace dynablaster.shared_libs.callbacks
{
    //bomb event signifies: 1) bomb was placed by a player, 2) bomb exploded
	[Serializable]
	public class BombEventArgs : DynaEventArgs
	{

		private Bomb explodedBomb;
        		
		public BombEventArgs(IList bombs, Bomb explodedBomb){			
			this.explodedBomb=explodedBomb;		
		}		

        public BombEventArgs(GameState gameState):base(gameState){            
        }

        public BombEventArgs(GameState gameState,Bomb explodedBomb): base(gameState){            
            this.explodedBomb= explodedBomb;
        }

		public bool BombExploded(){
            if(explodedBomb==null)
                return false;
            return true;
        }
		
		public Bomb GetBombExploded(){
            return this.explodedBomb;
        }
	}

}

