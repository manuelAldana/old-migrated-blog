using System;
using dynablaster.shared_libs.callbacks;
using dynablaster.shared_libs.game.gameObjects;
using dynablaster.shared_libs.game;

namespace dynablaster.shared_libs.callbacks
{
	/// <summary>
	/// EventArgs der fall, wo sich ein spieler bewegt hat und dieses
	/// wird hier angezeigt
	/// </summary>
	[Serializable] 
	public class PlayerMovedArgs : DynaEventArgs
	{
        public PlayerMovedArgs(GameState gameState):base(gameState){            
        }


	}
}
