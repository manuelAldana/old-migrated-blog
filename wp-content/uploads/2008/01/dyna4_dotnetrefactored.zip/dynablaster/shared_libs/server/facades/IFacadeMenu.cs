using System;

using dynablaster.shared_libs.callbacks;

namespace dynablaster.shared_libs.server.facades
{
    //offers methods for client regarding the menu stage (registering, joining, starting game)
	public interface IFacadeMenu{

        //PRE: game does not exist yet
        //POST: game is registered with name in menu stage, player with his callbacks were added to game 
		void NewGame(string game, string player,JoinEvent joinEvent,StartEvent startEvent,GameEvent gameEvent);
		//QUERY : return all games which have not started yet
		string[] GetAvailableGames();
		//PRE: game exists
        //POST: player with name and his events were added to game
		void JoinGame(string game, string player,StartEvent startEvent,GameEvent gameEvent);
		//PRE: game exists
        //POST: game is removed from list of menu games, and added to list of started games
		void StartGame(string game);   
	}
}
