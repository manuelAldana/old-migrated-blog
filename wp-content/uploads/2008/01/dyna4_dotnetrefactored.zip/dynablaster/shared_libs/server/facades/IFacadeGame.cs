using System;
using dynablaster.shared_libs.callbacks;

namespace dynablaster.shared_libs.server.facades
{
	
	//offers methods to client regarding the game state (playing the real game)
    //games are identified by game name, player by their names too
	public interface IFacadeGame
	{
		//PRE: game and player (as names) exist, move up cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
		void PlayerMoveUp(string gameName, string playerName);
        //PRE: game and player (as names) exist, move right cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
        void PlayerMoveRight(string gameName, string playerName);
        //PRE: game and player (as names) exist, move down cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
        void PlayerMoveDown(string gameName, string playerName);
        //PRE: game and player (as names) exist, move left cannot go outside gameField 
        //POST: player goes up of gameField if no obstacle is in way OR finds treasure
        void PlayerMoveLeft(string gameName, string playerName);
		//PRE: player and game (as names) exist, players stands on non obstacle field
        //POST: bomb is placed on coordinates of player 
        void PlaceBomb(string gameName, string playerName);

		//PRE: game name exists
        //POST: game is removed from started games list XOR is still kept in started games list
		void ClientSendsFinishedGame(string gameName);
	}
}
