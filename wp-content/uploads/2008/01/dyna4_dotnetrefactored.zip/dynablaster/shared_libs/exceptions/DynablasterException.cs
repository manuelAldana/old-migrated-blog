using System;
using System.Runtime.Serialization;

namespace dynablaster.shared_libs.exceptions
{
	/// <summary>
	/// Exception f�r Fehler, die in der Spiellogik auftreten k�nnten,
	/// wird an den Client weitergeleitet, als information lediglich text...
	/// </summary>
	[Serializable]
	public class DynablasterException : ApplicationException
	{
		public DynablasterException(string s):base(s)
		{
		}

		public DynablasterException(SerializationInfo info,StreamingContext context):base(info,context)
		{
		}
	}
}
