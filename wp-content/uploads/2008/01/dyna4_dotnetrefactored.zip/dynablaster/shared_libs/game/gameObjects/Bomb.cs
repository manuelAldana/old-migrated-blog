using System;

using System.Collections;

using dynablaster.shared_libs.callbacks;


namespace dynablaster.shared_libs.game.gameObjects
{
	[Serializable]
	public class Bomb
	{
		
		//power of bomb, number of neighbour fields which are affected by bomb explosion
		public static int power=1;
		
		private int xEpicenter;		
		private int yEpicenter;
		
        private bool exploded;
	

		public Bomb(int xEpicenter, int yEpicenter)
		{
			Console.WriteLine("placing new bomb...");
			this.xEpicenter=xEpicenter;
			this.yEpicenter=yEpicenter;
			
			//bombe ist initial nicht explodiert, erst durch timer explodiert sie
			this.exploded=false;
		}

		
		public void SetExploded(){this.exploded=true;}
		public bool GetExplodes(){return this.exploded;}
		public int GetXCoord(){return this.xEpicenter;}
		public int GetYCoord(){return this.yEpicenter;}
	}
}
