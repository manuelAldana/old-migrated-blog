using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

using dynablaster.shared_libs.game.gameObjects;

namespace dynablaster.shared_libs.game
{
    [Serializable]
    public class GameState
    {
        
        public static GameState CreateGameInitGameState(Field[,] map,IList players){
            return new GameState(map, players);            
        }

        public Field[,] cachedMap;
        public IList cachedPlayers;
        public IList cachedBombs;
        public bool gameStarted = false;
        public bool gameFinished = false;                

        public GameState(){
        }

        public GameState(Field[,] map,IList players){
            this.cachedMap = map;
            this.cachedPlayers = players;
            this.cachedBombs = new ArrayList();
        }                

        public void AddBomb(Bomb bomb){
            this.cachedBombs.Add(bomb);
        }

        public void RemoveBombAt(int x,int y){
            Bomb bombToBeRemoved = GetBombAt(x, y);
            this.cachedBombs.Remove(bombToBeRemoved);
        }

        public void RemovePlayer(Player player){
            this.cachedPlayers.Remove(player);
        }

        public bool AllPlayersDead(){
            if (this.cachedPlayers.Count == 0)
                return true;
            return false;
        }

        
        private Bomb GetBombAt(int x, int y)
        {
            foreach (Bomb b in this.cachedBombs)
                if (b.GetXCoord() == x && b.GetYCoord() == y)
                    return b;
            Console.WriteLine("Fehler, es h�tte eine Bombe auf ({0},{1})" +
                                " gefunden werden m�ssen", x, y);
            return null;
        }


        public int XBound{
            get{return this.cachedMap.GetLength(0) - 1;}
        }
        public int YBound{
            get{return this.cachedMap.GetLength(1) - 1;}
        }   

        public Player getPlayerByName(string name){
            foreach (Player player in cachedPlayers)
                if (player.GetName().Equals(name))
                    return player;
            return null;
        }

        public void UpdatePlayerCoordinates(Player playerWithFreshCoordinates){
            Player playerWithOldCoordinates = getPlayerByName(playerWithFreshCoordinates.GetName());
            playerWithOldCoordinates.setXCoord(playerWithFreshCoordinates.getXCoord());
            playerWithOldCoordinates.setYCoord(playerWithFreshCoordinates.getYCoord());
        }		
    }
}
