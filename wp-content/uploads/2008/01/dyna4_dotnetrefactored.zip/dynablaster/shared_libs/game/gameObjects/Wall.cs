using System;
 

namespace dynablaster.shared_libs.game.gameObjects
{
	//wall is an obstacle which can not be destroyed by a bomb
	[Serializable]
	public class Wall : Field
	{
		
        public override bool IsObstacle(){
            return true;
        }

		public Wall(int x, int y) : base(x,y)
        {
			
		}
	}
}
