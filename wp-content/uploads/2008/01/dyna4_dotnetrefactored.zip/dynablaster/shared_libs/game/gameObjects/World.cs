using System;


namespace dynablaster.shared_libs.game.gameObjects
{
	//world is the representation of all fields 
	public abstract class World
	{

		public Field[,] map;
		public int x;
		public int y;
	
		public World()
		{
			
		}

		public Field[,] GetMap()
		{
			return this.map;
		}

		public int GetX(){return this.x;}
		public int GetY(){return this.y;}
		
		
	}
}
