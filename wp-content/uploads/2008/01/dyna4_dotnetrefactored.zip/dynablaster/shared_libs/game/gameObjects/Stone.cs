using System;


namespace dynablaster.shared_libs.game.gameObjects
{
	//stone is an obstacle which can be destroyed by bomb
    [Serializable]
	public class Stone : Field
	{
        public override bool IsObstacle()
        {
            return true;
        }
		

		public Stone(int x, int y):base(x,y)
		{
			
		}
	}
}
