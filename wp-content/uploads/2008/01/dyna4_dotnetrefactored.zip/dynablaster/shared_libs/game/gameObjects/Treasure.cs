using System;



namespace dynablaster.shared_libs.game.gameObjects
{
	
	[Serializable]
	public class Treasure : Field
    {
        
        public override bool IsObstacle(){
            return false;
        }

        public Treasure(int x, int y) : base(x,y)
		{
			
		}
	}
}
