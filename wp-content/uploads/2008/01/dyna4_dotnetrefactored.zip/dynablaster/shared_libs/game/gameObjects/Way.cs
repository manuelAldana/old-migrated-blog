using System;
using System.Collections;


namespace dynablaster.shared_libs.game.gameObjects
{
	//ways are fields which can be moved onto by players or bomb can be placed on
	[Serializable]
	public class Way : Field
	{

		
		public Way(int x, int y) :base(x,y)
		{
			
		}
        
        public override bool IsObstacle(){
            return false;
        }


	}
}
