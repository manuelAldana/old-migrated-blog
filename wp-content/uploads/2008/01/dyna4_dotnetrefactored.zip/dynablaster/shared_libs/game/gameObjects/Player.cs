using System;


namespace dynablaster.shared_libs.game.gameObjects
{
    
    [Serializable]
    public class Player
    {
        public const int MOVE_UP = 0;
        public const int MOVE_RIGHT = 1;
        public const int MOVE_DOWN = 2;
        public const int MOVE_LEFT = 3;

        
        private int playerNumber;        
        private string playerName;

        private int xCoord;
        private int yCoord;

        public Player(int playerNumber, string playerName, int xCoord, int yCoord)
        {
            this.playerNumber = playerNumber;
            this.playerName = playerName;
            this.xCoord = xCoord;
            this.yCoord = yCoord;
        }

        public string GetName()
        {
            return this.playerName;
        }

        public int GetNumber()
        {
            return this.playerNumber;
        }

        public void setXCoord(int x) { this.xCoord = x; }
        public void setYCoord(int y) { this.yCoord = y; }
        public int getXCoord() { return this.xCoord; }
        public int getYCoord() { return this.yCoord; }


        public override bool Equals(object obj)
        {
            Player player = (Player)obj;
            if (player.GetName().Equals(this.GetName()))
                return true;
            return false;
        }

        public void Move(int direction){
            if (direction == Player.MOVE_LEFT)
                MoveLeft();
            if (direction == Player.MOVE_RIGHT)
                MoveRight();
            if (direction == Player.MOVE_UP)
                MoveUp();
            if (direction == Player.MOVE_DOWN)
                MoveDown();            
        }

        public void MoveLeft()
        {
            this.xCoord--;
        }

        public void MoveRight()
        {
            this.xCoord++;
        }

        public void MoveUp()
        {
            this.yCoord--;
        }

        public void MoveDown()
        {
            this.yCoord++;
        }


    }
}
