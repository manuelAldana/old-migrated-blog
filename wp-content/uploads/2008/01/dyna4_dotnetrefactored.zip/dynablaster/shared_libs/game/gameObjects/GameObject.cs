using System;


namespace dynablaster.shared_libs.game.gameObjects
{
	
	[Serializable]
	public abstract class Field
	{
		
		private int xCoord;		
		private int yCoord;

		public Field(int coordX, int coordY)
		{
			this.xCoord=coordX;
			this.yCoord=coordY;
		}
        
		public int getCoordX(){return this.xCoord;}
		public int getCoordY(){return this.yCoord;}

        public abstract bool IsObstacle();


	}
}
