using System;
using System.Collections.Generic;
using System.Text;

namespace dynablaster.shared_libs.utils
{

    public class AssertException :Exception{
        public AssertException(string message):base(message){
        }
    }

    public class Asserts
    {
        public static void codeNotReached(string message){
            throw new AssertException(message);
        }

    }
}
